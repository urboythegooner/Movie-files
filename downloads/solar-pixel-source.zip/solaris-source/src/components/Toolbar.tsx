import { Backpack, Disc3, Globe, MousePointer2, Sparkles } from 'lucide-react';
import { cn } from '@project/components/lib/utils';
import { Tool } from '../sim/sim';

const TOOLS: { id: Tool; label: string; icon: typeof Globe; key: string; hint: string }[] = [
  { id: 'select', label: 'Grab', icon: MousePointer2, key: '1', hint: 'Drag planets · drag space to rotate' },
  { id: 'asteroid', label: 'Asteroids', icon: Sparkles, key: '2', hint: 'Click or drag to spray asteroids' },
  { id: 'blackhole', label: 'Black hole', icon: Disc3, key: '3', hint: 'Click to drop a black hole' },
  { id: 'planet', label: 'Planet', icon: Globe, key: '4', hint: 'Click to add an orbiting planet' },
];

export default function Toolbar({ tool, onChange, onInventory }: { tool: Tool; onChange: (t: Tool) => void; onInventory: () => void }) {
  return (
    <div className="panel flex flex-col gap-1 p-1.5">
      {TOOLS.map((t) => (
        <button
          key={t.id}
          title={`${t.hint} (${t.key})`}
          onClick={() => onChange(t.id)}
          className={cn(
            'group flex items-center gap-2 rounded-md px-2.5 py-2 text-xs transition-colors',
            tool === t.id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-accent hover:text-foreground',
          )}
        >
          <t.icon className="h-4 w-4 shrink-0" />
          <span className="hidden sm:inline">{t.label}</span>
          <kbd className="ml-auto hidden text-[10px] opacity-60 sm:inline">{t.key}</kbd>
        </button>
      ))}
      <div className="my-0.5 h-px bg-border" />
      <button
        title="Inventory: spawn planets, stars and more (I)"
        onClick={onInventory}
        className={cn('flex items-center gap-2 rounded-md px-2.5 py-2 text-xs transition-colors', tool === 'place' ? 'bg-primary text-primary-foreground' : 'text-primary hover:bg-accent')}
      >
        <Backpack className="h-4 w-4 shrink-0" />
        <span className="hidden sm:inline">Inventory</span>
        <kbd className="ml-auto hidden text-[10px] opacity-60 sm:inline">I</kbd>
      </button>
    </div>
  );
}

export const toolHint = (t: Tool) => TOOLS.find((x) => x.id === t)?.hint ?? 'Click in space to place · Esc to stop';
