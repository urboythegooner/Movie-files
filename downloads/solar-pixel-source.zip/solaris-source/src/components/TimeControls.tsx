import { Cpu, Feather, Pause, Play, Turtle } from 'lucide-react';
import { Slider } from '@project/components/ui/slider';
import { Button } from '@project/components/ui/button';
import { Settings } from '../sim/sim';

interface Props { s: Settings; update: (p: Partial<Settings>) => void; onUltra: (v: boolean) => void }

export default function TimeControls({ s, update, onUltra }: Props) {
  return (
    <div className="panel flex items-center gap-2 p-1.5">
      <Button size="icon" variant="ghost" className="h-8 w-8" title="Pause (Space)" onClick={() => update({ paused: !s.paused })}>
        {s.paused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
      </Button>
      <Button
        size="sm"
        variant={s.slow ? 'default' : 'ghost'}
        className="h-8 gap-1.5 px-2 text-xs"
        title="Slow motion (G)"
        onClick={() => update({ slow: !s.slow })}
      >
        <Turtle className="h-4 w-4" /> G
      </Button>
      <Button
        size="sm"
        variant={s.simple ? 'default' : 'ghost'}
        className="h-8 gap-1.5 px-2 text-xs"
        title="Simple mode: fewer details, less lag (L)"
        onClick={() => { if (s.ultra) onUltra(false); update({ simple: !s.simple }); }}
      >
        <Feather className="h-4 w-4" /> <span className="hidden sm:inline">Simple</span>
      </Button>
      <Button
        size="sm"
        variant={s.ultra ? 'default' : 'ghost'}
        className="h-8 gap-1.5 px-2 text-xs"
        title="Ultra mode for powerful computers: tons of detail and realistic spacing. Rebuilds the solar system. (U)"
        onClick={() => onUltra(!s.ultra)}
      >
        <Cpu className="h-4 w-4" /> <span className="hidden sm:inline">Ultra</span>
      </Button>
      <div className="hidden w-28 items-center gap-2 pr-2 sm:flex">
        <Slider min={0.1} max={s.ultra ? 20 : 6} step={0.1} value={[s.timeScale]} onValueChange={([v]) => update({ timeScale: v })} />
        <span className="w-9 text-right text-[11px] tabular-nums text-muted-foreground">{s.timeScale.toFixed(1)}×</span>
      </div>
    </div>
  );
}
