import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';

const SCENES = [
  { image: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=3840&q=95', title: 'Exploring the cosmos' },
  { image: 'https://images.unsplash.com/photo-1464802686167-b939a6910659?auto=format&fit=crop&w=3840&q=95', title: 'A universe of possibilities' },
  { image: 'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?auto=format&fit=crop&w=3840&q=95', title: 'Your universe is taking shape' },
  { image: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?auto=format&fit=crop&w=3840&q=95', title: 'Almost there' },
];

export default function LoadingScreen({ onComplete }: { onComplete: () => void }) {
  const [elapsed, setElapsed] = useState(0);
  const [scene, setScene] = useState(0);
  const completeRef = useRef(onComplete);
  completeRef.current = onComplete;
  useEffect(() => {
    const started = Date.now();
    const progress = window.setInterval(() => {
      const next = Math.min(100, ((Date.now() - started) / 18000) * 100);
      setElapsed(next);
      setScene(Math.min(SCENES.length - 1, Math.floor(next / 25)));
      if (next >= 100) {
        window.clearInterval(progress);
        completeRef.current();
      }
    }, 100);
    return () => window.clearInterval(progress);
  }, []);
  return (
    <motion.div className="solar-loading fixed inset-0 z-[80] flex items-end overflow-hidden"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: .55 }}>
      <div className="absolute inset-0 bg-[#02040a]" />
      <AnimatePresence mode="sync">
        {SCENES.map((s, i) => i === scene && (
          <motion.div key={s.image} className="solar-loading-scene absolute inset-0"
            style={{ backgroundImage: `url("${s.image}")` }}
            initial={{ opacity: 0, scale: 1.045 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ duration: 1.4, ease: 'easeInOut' }} />
        ))}
      </AnimatePresence>
      <div className="solar-loading-shade absolute inset-0" />
      <div className="relative z-10 mx-auto flex w-full max-w-7xl flex-col px-6 pb-9 pt-7 sm:px-12 sm:pb-12">
        <div className="flex items-center justify-between gap-4">
          <div className="text-sm font-semibold tracking-[.24em] text-white drop-shadow-lg">SOLARIS <span className="ml-1 text-[9px] font-medium tracking-[.2em] text-white/65">BETA</span></div>
          <div className="text-right"><div className="text-[10px] font-semibold tracking-[.18em] text-white/85">THE BIG R <span className="text-cyan-200">✦</span></div><div className="mt-1 text-[8px] tracking-[.16em] text-white/55">COSMIC VISIONARY · GRAVITY ARCHITECT</div></div>
        </div>
        <div className="mt-[35vh] max-w-xl sm:mt-[32vh]">
          <AnimatePresence mode="wait">
            <motion.h1 key={SCENES[scene].title} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} transition={{ duration: .35 }}
              className="text-3xl font-light leading-tight tracking-[-.04em] text-white drop-shadow-lg sm:text-5xl">{SCENES[scene].title}</motion.h1>
          </AnimatePresence>
          <div className="mt-7 flex items-center justify-between text-xs text-white/75">
            <span>Entering sandbox</span><span className="font-mono tabular-nums">{Math.floor(elapsed)}%</span>
          </div>
          <div className="solar-loading-track mt-3"><motion.div className="solar-loading-progress" style={{ width: `${elapsed}%` }} /></div>
        </div>
      </div>
    </motion.div>
  );
}
