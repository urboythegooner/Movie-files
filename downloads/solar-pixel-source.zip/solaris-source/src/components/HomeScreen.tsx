import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Atom, ChevronRight, CircleHelp, FolderOpen, Gauge, Globe2, Play, Settings2, ShieldCheck, Trash2, Waves } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Button } from '@project/components/ui/button';
import { Switch } from '@project/components/ui/switch';
import { Label } from '@project/components/ui/label';
import { deleteSave, listSaves, Prefs, savePrefs } from '../sim/saves';

type View = 'menu' | 'load' | 'settings';
interface Props { prefs: Prefs; setPrefs: (p: Prefs) => void; onNew: () => void; onLoad: (id: string) => void }

export default function HomeScreen({ prefs, setPrefs, onNew, onLoad }: Props) {
  const [view, setView] = useState<View>('menu');
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="launcher absolute inset-0 z-30 flex items-center overflow-y-auto p-4 sm:p-8">
      <div className="launcher-grid pointer-events-none absolute inset-0" />
      <div className="relative mx-auto grid w-full max-w-6xl items-center gap-8 py-8 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16">
        <motion.section initial={{ opacity: 0, x: -18 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.65 }}
          className="max-w-2xl text-left">
          <div className="mb-7 flex items-center gap-3">
            <div className="brand-mark"><Atom size={23} strokeWidth={1.5} /></div>
            <div>
              <div className="brand-wordmark">SOLARIS</div>
              <div className="brand-submark">GRAVITY LABORATORY <span> / </span> BUILD 01.8</div>
            </div>
          </div>
          <div className="mb-4 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.24em] text-cyan-200/80">
            <span className="live-dot" /> Open universe simulation
          </div>
          <h1 className="launcher-title">A universe<br /><span>in your hands.</span></h1>
          <p className="mt-6 max-w-xl text-sm leading-7 text-slate-300/75 sm:text-base">
            Create star systems. Sculpt gravity. Watch worlds form, collide, melt and evolve. Every orbit is an experiment and every catastrophe leaves a mark.
          </p>
          <div className="mt-8 grid max-w-xl grid-cols-3 gap-3">
            <Feature icon={<Globe2 size={17} />} title="N-body gravity" sub="Live orbital dynamics" />
            <Feature icon={<Waves size={17} />} title="World evolution" sub="Heat & collisions" />
            <Feature icon={<Gauge size={17} />} title="Your universe" sub="Tools without limits" />
          </div>
          <div className="mt-8 hidden items-center gap-2 text-[10px] tracking-wide text-slate-400/65 sm:flex">
            <ShieldCheck size={13} /> SANDBOX SIMULATION <span className="mx-1 text-slate-600">•</span> NO MISSIONS. NO RULES. JUST PHYSICS.
          </div>
        </motion.section>
        <motion.section initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.12 }}
          className="launcher-menu">
          <div className="mb-5 flex items-start justify-between">
            <div>
              <div className="menu-eyebrow">MISSION CONTROL</div>
              <h2 className="mt-1 text-xl font-semibold tracking-tight text-white">{view === 'menu' ? 'Enter the sandbox' : view === 'load' ? 'Saved universes' : 'Simulation settings'}</h2>
            </div>
            <div className="status-chip"><span className="live-dot" /> READY</div>
          </div>
          {view === 'menu' && <Menu onNew={onNew} go={setView} />}
          {view === 'load' && <LoadList onLoad={onLoad} back={() => setView('menu')} />}
          {view === 'settings' && <SettingsView prefs={prefs} setPrefs={(p) => { savePrefs(p); setPrefs(p); }} back={() => setView('menu')} />}
          <div className="mt-6 border-t border-white/10 pt-4 text-[10px] text-slate-400/70">
            <div className="flex items-center justify-between gap-3"><span>PHYSICS ENGINE <b className="ml-1 font-medium text-slate-300">N-BODY / 3D SPACE</b></span><span>v1.8.0</span></div>
            <div className="mt-2 flex items-center gap-1.5"><CircleHelp size={12} /> Tip: right-drag to rotate · middle-drag to pan · scroll to zoom</div>
          </div>
        </motion.section>
      </div>
    </motion.div>
  );
}

function Feature({ icon, title, sub }: { icon: React.ReactNode; title: string; sub: string }) {
  return <div className="feature-tile"><div className="mb-3 text-cyan-200/90">{icon}</div><div className="text-xs font-semibold text-slate-100">{title}</div><div className="mt-1 text-[10px] leading-4 text-slate-400">{sub}</div></div>;
}

function Menu({ onNew, go }: { onNew: () => void; go: (v: View) => void }) {
  const has = listSaves().length > 0;
  return (
    <div className="flex flex-col gap-2.5">
      <Button size="lg" onClick={onNew} className="launcher-primary h-12 justify-between px-4 text-sm font-semibold">
        <span className="flex items-center"><Play className="mr-3 h-4 w-4" /> Create new universe</span><ChevronRight size={17} />
      </Button>
      <Button size="lg" variant="secondary" disabled={!has} onClick={() => go('load')} className="launcher-secondary h-11 justify-start px-4 text-sm">
        <FolderOpen className="mr-3 h-4 w-4" /> Continue simulation <span className="ml-auto text-[10px] opacity-60">{has ? `${listSaves().length} SAVED` : 'NO SAVES'}</span>
      </Button>
      <Button size="lg" variant="outline" onClick={() => go('settings')} className="launcher-secondary h-11 justify-start px-4 text-sm">
        <Settings2 className="mr-3 h-4 w-4" /> Graphics & simulation
      </Button>
    </div>
  );
}

function Header({ title, back }: { title: string; back: () => void }) {
  return <div className="mb-4 flex items-center gap-2"><Button size="icon" variant="ghost" className="h-8 w-8 text-slate-300 hover:bg-white/10 hover:text-white" onClick={back}><ArrowLeft className="h-4 w-4" /></Button><span className="text-xs font-semibold tracking-widest text-slate-200">{title}</span></div>;
}

function LoadList({ onLoad, back }: { onLoad: (id: string) => void; back: () => void }) {
  const [saves, setSaves] = useState(listSaves);
  return <div><Header title="LOAD UNIVERSE" back={back} />
    {saves.length === 0 && <p className="py-6 text-center text-xs text-slate-400">No saved universes yet.</p>}
    <div className="max-h-72 space-y-2 overflow-y-auto">
      {saves.map((s) => <div key={s.id} className="save-row flex items-center gap-2 p-3">
        <button className="min-w-0 flex-1 text-left" onClick={() => onLoad(s.id)}>
          <div className="truncate text-sm font-medium text-white">{s.name}{s.ultra && <span className="ml-2 text-[9px] tracking-widest text-cyan-200">ULTRA</span>}</div>
          <div className="mt-1 text-[10px] text-slate-400">{s.bodies} celestial bodies · {formatDistanceToNow(s.savedAt, { addSuffix: true })}</div>
        </button>
        <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-400 hover:text-red-300" onClick={() => { deleteSave(s.id); setSaves(listSaves()); }}><Trash2 className="h-3.5 w-3.5" /></Button>
      </div>)}
    </div>
  </div>;
}

const TOGGLES: [keyof Prefs, string, string][] = [['prediction', 'Orbital prediction', 'Calculate projected future paths'], ['trails', 'Orbit trails', 'Show recent body trajectories'], ['labels', 'Celestial labels', 'Name bodies and display temperatures'], ['orbitAssist', 'Orbit placement assist', 'Suggest stable velocity when placing bodies']];

function SettingsView({ prefs, setPrefs, back }: { prefs: Prefs; setPrefs: (p: Prefs) => void; back: () => void }) {
  return <div><Header title="PREFERENCES" back={back} />
    <Label className="text-[10px] uppercase tracking-widest text-slate-400">Rendering quality</Label>
    <div className="mt-2 grid grid-cols-3 gap-1.5">
      {(['simple', 'normal', 'ultra'] as const).map((m) => <Button key={m} size="sm" variant={prefs.mode === m ? 'default' : 'outline'} className={`h-9 capitalize ${prefs.mode === m ? 'bg-cyan-300 text-slate-950 hover:bg-cyan-200' : 'border-white/10 bg-white/[0.03] text-slate-300 hover:bg-white/10'}`} onClick={() => setPrefs({ ...prefs, mode: m })}>{m}</Button>)}
    </div>
    <div className="mt-5 space-y-4">{TOGGLES.map(([k, label, desc]) => <div key={k} className="flex items-center justify-between gap-3">
      <div><Label htmlFor={k} className="text-sm text-slate-100">{label}</Label><p className="mt-1 text-[10px] text-slate-400">{desc}</p></div>
      <Switch id={k} checked={prefs[k] as boolean} onCheckedChange={(v) => setPrefs({ ...prefs, [k]: v })} />
    </div>)}</div>
  </div>;
}
