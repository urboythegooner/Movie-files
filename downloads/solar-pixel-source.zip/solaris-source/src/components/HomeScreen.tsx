import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, ChevronRight, CircleHelp, FolderOpen, Play, Settings2, Trash2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Button } from '@project/components/ui/button';
import { Switch } from '@project/components/ui/switch';
import { Slider } from '@project/components/ui/slider';
import { Label } from '@project/components/ui/label';
import { deleteSave, listSaves, Prefs, savePrefs } from '../sim/saves';

type View = 'menu' | 'load' | 'settings' | 'about';
interface Props { prefs: Prefs; setPrefs: (p: Prefs) => void; onNew: () => void; onLoad: (id: string) => void }

export default function HomeScreen({ prefs, setPrefs, onNew, onLoad }: Props) {
  const [view, setView] = useState<View>('menu');
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="launcher absolute inset-0 z-30 flex items-center overflow-y-auto p-4 sm:p-8">
      <div className="launcher-space-art pointer-events-none absolute inset-0" aria-hidden="true" />
      <div className="launcher-grid pointer-events-none absolute inset-0" />
      <motion.section initial={{ opacity: 0, x: -14 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.75 }}
        className="launcher-sidebar relative z-10 flex min-h-[570px] w-full max-w-[330px] flex-col justify-center px-2 py-8 sm:ml-8 sm:px-4">
        <div className="launcher-brand mb-7 flex items-center gap-3">
          <div>
            <div className="flex items-center gap-2"><div className="launcher-brand-title">SOLARIS</div><span className="beta-chip">BETA</span></div>
            <div className="launcher-brand-sub">GRAVITY SANDBOX</div>
          </div>
        </div>
        {view === 'menu' && <>
          <div className="launcher-nav flex flex-col gap-2.5">
            <button className="horizon-button" onClick={onNew}><span className="horizon-label">START GAME</span><ChevronRight size={14} className="nav-chevron" /></button>
            <button className="horizon-button" disabled={!listSaves().length} onClick={() => setView('load')}><span className="horizon-label">RESUME GAME</span><ChevronRight size={14} className="nav-chevron" /></button>
            <button className="horizon-button" onClick={() => setView('settings')}><span className="horizon-label">OPTIONS</span><ChevronRight size={14} className="nav-chevron" /></button>
            <button className="horizon-button" onClick={() => setView('about')}><span className="horizon-label">AUTHORS</span><ChevronRight size={14} className="nav-chevron" /></button>
          </div>
          <div className="mt-6 max-w-[255px] border-t border-white/10 pt-4 text-[10px] leading-5 text-slate-300/75">
            <div className="font-medium tracking-[.08em] text-stone-100">YOUR UNIVERSE. YOUR RULES.</div>
            <p className="mt-1">Build worlds, bend gravity, and see what survives.</p>
          </div>
        </>}
        {view === 'load' && <div className="horizon-submenu"><LoadList onLoad={onLoad} back={() => setView('menu')} /></div>}
        {view === 'settings' && <div className="horizon-submenu"><SettingsView prefs={prefs} setPrefs={(p) => { savePrefs(p); setPrefs(p); }} back={() => setView('menu')} /></div>}
        {view === 'about' && <div className="horizon-submenu"><Header title="AUTHORS & ORIGINS" back={() => setView('menu')} /><div className="relative overflow-hidden rounded-xl border border-cyan-300/25 bg-gradient-to-br from-cyan-300/10 via-slate-950/80 to-violet-500/10 p-4"><div className="text-[9px] font-semibold tracking-[.28em] text-stone-300">THE MIND BEHIND THE COSMOS</div><h2 className="mt-2 text-2xl font-black tracking-tight text-white">THE BIG R<span className="text-white">.</span></h2><div className="mt-1 text-[10px] tracking-[.18em] text-stone-300">CREATOR · WORLD-BUILDER · GRAVITY ARCHITECT</div><p className="mt-3 text-xs leading-5 text-slate-200">One big idea. An entire universe to play with. The Big R brings SOLARIS to life—a cosmic playground where stars ignite, planets find their paths, and gravity writes the rules.</p><p className="mt-3 text-xs leading-5 text-slate-300">Equal parts imagination and orbital chaos, this is a place to experiment boldly, build impossible systems, and see what happens when you take the universe into your own hands.</p><div className="mt-4 grid grid-cols-2 gap-2"><div className="rounded-lg border border-white/10 bg-black/20 p-2"><div className="text-[9px] tracking-widest text-cyan-200">THE VISION</div><div className="mt-1 text-[11px] font-semibold text-white">Make space playable</div></div><div className="rounded-lg border border-white/10 bg-black/20 p-2"><div className="text-[9px] tracking-widest text-violet-200">THE MISSION</div><div className="mt-1 text-[11px] font-semibold text-white">Build your own cosmos</div></div></div></div><p className="py-3 text-[10px] leading-4 text-slate-500">SOLARIS is an evolving beta project created by The Big R. Every universe is a new chance to make something legendary.</p><div className="mt-2 rounded-xl border border-white/15 bg-black/25 p-3"><div className="text-[9px] font-semibold tracking-[.22em] text-stone-300">DOWNLOAD THE GAME</div><p className="mt-1 text-[10px] leading-4 text-slate-400">Keep a copy of SOLARIS or download the complete project bundle.</p><div className="mt-3 grid grid-cols-2 gap-2"><a className="horizon-button flex items-center justify-between gap-2 px-3 py-2 text-[10px] no-underline" href="/downloads/solar-pixel-standalone.html" download="solar-pixel-standalone.html"><span>HTML GAME</span><span aria-hidden="true">↓</span></a><a className="horizon-button flex items-center justify-between gap-2 px-3 py-2 text-[10px] no-underline" href="/downloads/solar-pixel-complete.zip" download="solar-pixel-complete.zip"><span>GAME ZIP</span><span aria-hidden="true">↓</span></a></div><a className="mt-2 block text-[10px] text-slate-300 underline decoration-white/25 underline-offset-4 hover:text-white" href="/downloads/">View all downloads</a></div></div>}
        <div className="launcher-footer mt-auto pt-10">
          <div>CREATED BY THE BIG R</div>
          <div className="mt-1">SOLARIS · ORBITAL PHYSICS SIMULATION</div>
        </div>
      </motion.section>
    </motion.div>
  );
}

function Feature({ icon, title, sub }: { icon: React.ReactNode; title: string; sub: string }) {
  return <div className="feature-tile"><div className="mb-3 text-cyan-200/90">{icon}</div><div className="text-xs font-semibold text-slate-100">{title}</div><div className="mt-1 text-[10px] leading-4 text-slate-400">{sub}</div></div>;
}

function Menu({ onNew, go }: { onNew: () => void; go: (v: View) => void }) {
  const has = listSaves().length > 0;
  return (
    <div className="flex flex-col gap-2.5">
      <Button size="lg" onClick={onNew} className="launcher-primary h-12 justify-between px-4 text-sm font-semibold">
        <span className="flex items-center"><Play className="mr-3 h-4 w-4" /> Create new universe</span><ChevronRight size={17} />
      </Button>
      <Button size="lg" variant="secondary" disabled={!has} onClick={() => go('load')} className="launcher-secondary h-11 justify-start px-4 text-sm">
        <FolderOpen className="mr-3 h-4 w-4" /> Continue simulation <span className="ml-auto text-[10px] opacity-60">{has ? `${listSaves().length} SAVED` : 'NO SAVES'}</span>
      </Button>
      <Button size="lg" variant="outline" onClick={() => go('settings')} className="launcher-secondary h-11 justify-start px-4 text-sm">
        <Settings2 className="mr-3 h-4 w-4" /> Graphics & simulation
      </Button>
    </div>
  );
}

function Header({ title, back }: { title: string; back: () => void }) {
  return <div className="mb-4 flex items-center gap-2"><Button size="icon" variant="ghost" className="h-8 w-8 text-slate-300 hover:bg-white/10 hover:text-white" onClick={back}><ArrowLeft className="h-4 w-4" /></Button><span className="text-xs font-semibold tracking-widest text-slate-200">{title}</span></div>;
}

function LoadList({ onLoad, back }: { onLoad: (id: string) => void; back: () => void }) {
  const [saves, setSaves] = useState(listSaves);
  return <div><Header title="LOAD UNIVERSE" back={back} />
    {saves.length === 0 && <p className="py-6 text-center text-xs text-slate-400">No saved universes yet.</p>}
    <div className="max-h-72 space-y-2 overflow-y-auto">
      {saves.map((s) => <div key={s.id} className="save-row flex items-center gap-2 p-3">
        <button className="min-w-0 flex-1 text-left" onClick={() => onLoad(s.id)}>
          <div className="truncate text-sm font-medium text-white">{s.name}{s.ultra && <span className="ml-2 text-[9px] tracking-widest text-cyan-200">ULTRA</span>}</div>
          <div className="mt-1 text-[10px] text-slate-400">{s.bodies} celestial bodies · {formatDistanceToNow(s.savedAt, { addSuffix: true })}</div>
        </button>
        <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-400 hover:text-red-300" onClick={() => { deleteSave(s.id); setSaves(listSaves()); }}><Trash2 className="h-3.5 w-3.5" /></Button>
      </div>)}
    </div>
  </div>;
}

const TOGGLES: [keyof Prefs, string, string][] = [['prediction', 'Orbital prediction', 'Calculate projected future paths'], ['trails', 'Orbit trails', 'Show recent body trajectories'], ['labels', 'Celestial labels', 'Name bodies and display temperatures'], ['orbitAssist', 'Orbit placement assist', 'Suggest stable velocity when placing bodies']];

function SettingsView({ prefs, setPrefs, back }: { prefs: Prefs; setPrefs: (p: Prefs) => void; back: () => void }) {
  return <div><Header title="PREFERENCES" back={back} />
    <Label className="text-[10px] uppercase tracking-widest text-slate-400">Rendering quality</Label>
    <div className="mt-2 rounded-md border border-cyan-300/25 bg-cyan-300/5 px-3 py-3">
      <div className="flex items-center justify-between gap-3"><div><div className="text-sm font-semibold tracking-wide text-cyan-100">Graphics & textures</div><p className="mt-1 text-[10px] text-slate-400">Lower for smoother performance, higher for detail.</p></div><span className="text-xs font-bold tabular-nums text-cyan-200">{prefs.graphicsQuality}%</span></div>
      <Slider className="mt-4" min={10} max={150} step={5} value={[prefs.graphicsQuality]} onValueChange={([v]) => setPrefs({ ...prefs, graphicsQuality: v })} />
      <div className="mt-2 flex justify-between text-[9px] text-slate-500"><span>SMOOTH / LOW</span><span>150% MAX DETAIL</span></div>
      <p className="mt-2 text-[10px] leading-4 text-slate-400">{prefs.graphicsQuality < 35 ? "Performance mode: lighter rendering and fewer effects." : prefs.graphicsQuality < 70 ? "Balanced mode: good detail with smoother performance." : prefs.graphicsQuality <= 100 ? "Ultra detail: richer planetary textures, lighting, and visual effects." : `EXTREME ${prefs.graphicsQuality}%: denser surface textures and up to ${((prefs.graphicsQuality / 100) ** 2).toFixed(2)}× render pixel density. Higher settings may reduce FPS.`}</p>
    </div>
    <div className="mt-5 space-y-4">
      <div className="rounded-md border border-cyan-300/25 bg-cyan-300/5 p-3">
        <div className="mb-1 flex items-center justify-between gap-2"><Label className="text-xs font-semibold text-cyan-100">Universe size</Label><span className="text-xs tabular-nums text-cyan-200">{prefs.universeSystems} systems</span></div>
        <p className="mb-3 text-[10px] leading-4 text-slate-400">Choose how many distant solar systems to generate in each new universe.</p>
        <Slider min={0} max={100} step={1} value={[prefs.universeSystems]} onValueChange={([v]) => setPrefs({ ...prefs, universeSystems: v })} />
        <div className="mt-1 flex justify-between text-[9px] text-slate-500"><span>0 systems</span><span>100 systems</span></div>
        <div className="mb-1 mt-4 flex items-center justify-between gap-2"><Label className="text-xs text-slate-200">Planets per system</Label><span className="text-xs tabular-nums text-cyan-200">{prefs.planetsPerSystem}</span></div>
        <Slider min={1} max={12} step={1} value={[prefs.planetsPerSystem]} onValueChange={([v]) => setPrefs({ ...prefs, planetsPerSystem: v })} />
        <p className="mt-2 text-[10px] leading-4 text-slate-400">Up to 1,200 distant planets. Settings are saved automatically and apply when you start a new universe.</p>
      </div>
      {TOGGLES.map(([k, label, desc]) => <div key={k} className="flex items-center justify-between gap-3">
      <div><Label htmlFor={k} className="text-sm text-slate-100">{label}</Label><p className="mt-1 text-[10px] text-slate-400">{desc}</p></div>
      <Switch id={k} checked={prefs[k] as boolean} onCheckedChange={(v) => setPrefs({ ...prefs, [k]: v })} />
    </div>)}</div>
  </div>;
}
