import { Bomb, Plus, RotateCcw } from 'lucide-react';
import { Switch } from '@project/components/ui/switch';
import { Slider } from '@project/components/ui/slider';
import { Button } from '@project/components/ui/button';
import { Settings, Sim } from '../sim/sim';

interface Props { sim: Sim; update: (p: Partial<Settings>) => void }

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-3 text-xs text-muted-foreground">
      {label}
      <Switch checked={checked} onCheckedChange={onChange} />
    </label>
  );
}

export default function WorldPanel({ sim, update }: Props) {
  const s = sim.settings;
  return (
    <div className="panel w-56 space-y-3 p-3">
      <div className="space-y-2">
        <Toggle label="Future paths" checked={s.prediction} onChange={(v) => update({ prediction: v })} />
        {s.prediction && (
          <div className="flex items-center gap-2">
            <Slider min={0.1} max={3} step={0.05} value={[s.horizonYears]} onValueChange={([v]) => update({ horizonYears: v })} />
            <span className="w-14 text-right text-[11px] tabular-nums text-muted-foreground">{s.horizonYears.toFixed(2)} yr</span>
          </div>
        )}
        <Toggle label="Trails" checked={s.trails} onChange={(v) => update({ trails: v })} />
        <Toggle label="Labels" checked={s.labels} onChange={(v) => update({ labels: v })} />
        <Toggle label="Orbit assist on drop" checked={s.orbitAssist} onChange={(v) => update({ orbitAssist: v })} />
        <Toggle label="Space travel" checked={s.travel} onChange={(v) => update({ travel: v })} />
        {s.travel && <p className="text-[10px] leading-snug text-muted-foreground">Select any populated world or colony to launch ships. Open the War Room (W) for factions and wars.</p>}
      </div>
      <div className="grid grid-cols-2 gap-1.5 border-t border-border pt-3">
        <Button size="sm" variant="secondary" className="h-8 gap-1 text-[11px]" onClick={() => sim.addBelt(500)}>
          <Plus className="h-3 w-3" /> 500 belt
        </Button>
        <Button size="sm" variant="secondary" className="h-8 gap-1 text-[11px]" onClick={() => sim.addSwarm(200)}>
          <Bomb className="h-3 w-3" /> Swarm
        </Button>
        <Button size="sm" variant="ghost" className="col-span-2 h-8 gap-1 text-[11px]" onClick={() => sim.reset()}>
          <RotateCcw className="h-3 w-3" /> Reset solar system
        </Button>
      </div>
    </div>
  );
}
