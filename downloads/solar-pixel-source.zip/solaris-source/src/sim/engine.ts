import { shade } from './colors';
import { factsFor, suitability } from './facts';

export const G = 1;
const EPS2 = 0.6;
const MAX_DEBRIS = 1800;

export type Kind = 'sun' | 'planet' | 'moon' | 'asteroid' | 'blackhole';

export interface Body {
  id: number;
  name: string;
  kind: Kind;
  x: number; y: number; z: number;
  vx: number; vy: number; vz: number;
  mass: number;
  baseMass: number;
  baseRadius: number;
  radius: number;
  color: string;
  ring: boolean;
  massive: boolean;
  alive: boolean;
  dragging: boolean;
  trail: number[];
  temperature: number;
  habitable: boolean;
  population: number;
  parentId: number | null;
  orbitR: number; orbitSpeed: number; orbitPhase: number; orbitTilt: number;
  /** Greenhouse / internal heat on top of what nearby stars provide (°C) */
  heatBase?: number;
}

export interface Debris {
  x: number; y: number; z: number;
  vx: number; vy: number; vz: number;
  life: number; max: number;
  color: string; size: number;
}

export interface Flash { x: number; y: number; z: number; r: number; life: number; max: number; color: string }

/** Expanding supernova blast front. Everything it reaches (planets, moons, asteroids) is obliterated. */
export interface Shockwave {
  x: number; y: number; z: number;
  r: number; speed: number; maxR: number;
  color: string; sourceId: number;
  hit: Set<number>;
}

export interface NewBody {
  name: string; kind: Kind;
  x: number; y: number; z: number;
  vx?: number; vy?: number; vz?: number;
  mass: number; radius: number; color: string; ring?: boolean;
  parentId?: number; orbitR?: number; orbitSpeed?: number; orbitPhase?: number; orbitTilt?: number;
}

const rank = (b: Body) => (b.kind === 'blackhole' ? 3 : b.kind === 'sun' ? 2 : 1);
const isMassive = (kind: Kind, mass: number) => (kind !== 'asteroid' && kind !== 'moon') || mass >= 0.001;

export function radiusFor(b: Pick<Body, 'kind' | 'mass' | 'baseMass' | 'baseRadius'>) {
  if (b.kind === 'blackhole') return 2.5 + Math.cbrt(b.mass) * 0.25;
  return Math.min(60, Math.max(0.4, b.baseRadius * Math.cbrt(b.mass / b.baseMass)));
}

export class World {
  bodies: Body[] = [];
  simple = false;
  ultra = false;
  debris: Debris[] = [];
  flashes: Flash[] = [];
  shockwaves: Shockwave[] = [];
  onImpact?: (strength: number, kind: Kind) => void;
  time = 0;
  nextId = 1;
  private trailClock = 0;
  private captureClock = 0;

  add(o: NewBody): Body {
    const b: Body = {
      id: this.nextId++, name: o.name, kind: o.kind,
      x: o.x, y: o.y, z: o.z, vx: o.vx ?? 0, vy: o.vy ?? 0, vz: o.vz ?? 0,
      mass: o.mass, baseMass: o.mass, baseRadius: o.radius, radius: o.radius,
      color: o.color, ring: !!o.ring, massive: isMassive(o.kind, o.mass),
      alive: true, dragging: false, trail: [],
      temperature: 0, habitable: false, population: 0,
      parentId: o.parentId ?? null, orbitR: o.orbitR ?? 0, orbitSpeed: o.orbitSpeed ?? 0, orbitPhase: o.orbitPhase ?? 0, orbitTilt: o.orbitTilt ?? 0,
    };
    const f = factsFor(o.name);
    b.temperature = f === factsFor('') && o.kind === 'planet' ? Math.round(278 * Math.sqrt(100 / Math.max(10, Math.hypot(o.x, o.z))) - 273) : f.temp;
    b.habitable = f.habitable; b.population = f.pop;
    if (b.kind === 'blackhole') b.radius = radiusFor(b);
    this.bodies.push(b);
    return b;
  }

  byId(id: number | null) {
    if (id == null) return undefined;
    return this.bodies.find((b) => b.id === id && b.alive);
  }

  setMass(b: Body, m: number) {
    b.mass = m;
    b.massive = isMassive(b.kind, m);
    b.radius = radiusFor(b);
  }

  step(dt: number) {
    if (dt > 0) {
      // Adaptive substeps reduce tunnelling when fast-moving bodies cross a collision
      // radius between frames. Keep a hard cap so busy sandboxes remain responsive.
      let fastest = 0;
      for (const b of this.bodies) {
        if (!b.alive || b.parentId != null || b.dragging) continue;
        fastest = Math.max(fastest, Math.hypot(b.vx, b.vy, b.vz));
      }
      const maxSteps = this.simple ? 6 : this.ultra ? 18 : 14;
      const travelSteps = Math.ceil((fastest * dt) / 0.75);
      const subs = Math.min(maxSteps, Math.max(1, Math.ceil(dt / 0.012), travelSteps));
      const h = dt / subs;
      for (let s = 0; s < subs; s++) {
        this.gravity(h);
        this.collide(s === subs - 1);
      }
      this.captureClock += dt;
      if (this.captureClock >= 0.15) {
        this.captureClock %= 0.15;
        this.captureNearbyAsteroids();
      }
      this.updateLife(dt);
      this.time += dt;
      this.updateDebris(dt);
      this.updateShockwaves(dt);
      for (let i = this.flashes.length - 1; i >= 0; i--) {
        this.flashes[i].life -= dt;
        if (this.flashes[i].life <= 0) this.flashes.splice(i, 1);
      }
      this.trailClock += dt;
      if (this.trailClock >= 0.25) {
        this.trailClock = 0;
        for (const b of this.bodies) {
          if (!b.alive || b.kind === 'asteroid' || b.kind === 'sun' || b.kind === 'moon') continue;
          b.trail.push(b.x, b.y, b.z);
          if (b.trail.length > 480) b.trail.splice(0, 3);
        }
      }
    }
    this.bodies = this.bodies.filter((b) => b.alive);
  }

  private gravity(h: number) {
    const M = this.bodies.filter((b) => b.alive && b.massive);
    for (const b of this.bodies) {
      if (!b.alive || b.dragging || b.parentId != null) continue;
      let ax = 0, ay = 0, az = 0;
      for (const m of M) {
        if (m === b) continue;
        const dx = m.x - b.x, dy = m.y - b.y, dz = m.z - b.z;
        const r2 = dx * dx + dy * dy + dz * dz + EPS2;
        const inv = (G * m.mass) / (r2 * Math.sqrt(r2));
        ax += dx * inv; ay += dy * inv; az += dz * inv;
      }
      b.vx += ax * h; b.vy += ay * h; b.vz += az * h;
    }
    for (const b of this.bodies) {
      if (!b.alive || b.dragging || b.parentId != null) continue;
      b.x += b.vx * h; b.y += b.vy * h; b.z += b.vz * h;
    }
    this.moonTime += h;
    this.placeMoons();
  }

  moonTime = 0;

  /** Moons ride fixed orbits around their planet (real moons are too close for the sandbox's scale) */
  placeMoons() {
    const parents = new Map<number, Body>();
    for (const b of this.bodies) if (b.alive && (b.kind === 'planet' || b.kind === 'sun' || b.kind === 'blackhole')) parents.set(b.id, b);
    for (const m of this.bodies) {
      if (m.parentId == null || !m.alive || m.dragging) continue;
      const p = parents.get(m.parentId);
      if (!p) { m.parentId = null; continue; }
      const R = p.radius * m.orbitR, a = m.orbitPhase + this.moonTime * m.orbitSpeed;
      const st = Math.sin(m.orbitTilt), ct = Math.cos(m.orbitTilt), c = Math.cos(a), s = Math.sin(a);
      m.x = p.x + R * c; m.y = p.y + R * s * st; m.z = p.z + R * s * ct;
      const v = R * m.orbitSpeed;
      m.vx = p.vx - v * s; m.vy = p.vy + v * c * st; m.vz = p.vz + v * c * ct;
    }
  }

  private collide(withSmall: boolean) {
    const M = this.bodies.filter((b) => b.alive && b.massive);
    const pool = withSmall ? this.bodies : M;
    for (const a of M) {
      if (!a.alive) continue;
      for (const b of pool) {
        if (b === a || !b.alive) continue;
        if (b.massive && b.id < a.id) continue;
        const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
        const rr = a.radius + b.radius;
        if (dx * dx + dy * dy + dz * dz < rr * rr) {
          this.impact(a, b);
          if (!a.alive) break;
        }
      }
    }
  }

  private impact(a: Body, b: Body) {
    const impactX = (a.x + b.x) * 0.5, impactY = (a.y + b.y) * 0.5, impactZ = (a.z + b.z) * 0.5;
    const impactSpeed = Math.hypot(a.vx - b.vx, a.vy - b.vy, a.vz - b.vz);
    let big = a, small = b;
    if (rank(b) > rank(a) || (rank(b) === rank(a) && b.mass > a.mass)) { big = b; small = a; }
    const impactStrength = Math.min(1, impactSpeed / 13 + Math.min(0.45, small.mass / Math.max(big.mass, 0.001)));
    this.onImpact?.(impactStrength, big.kind);
    if (big.kind === 'planet' || big.kind === 'moon') {
      const severity = Math.min(1, impactSpeed / 12 + small.mass / Math.max(big.mass, 0.0001));
      big.temperature = Math.min(6000, Math.max(big.temperature, 900 + severity * 2600));
      big.heatBase = Math.max(big.heatBase ?? 0, big.temperature - this.starHeat(big.x, big.y, big.z, this.bodies.filter((x) => x.alive && x.kind === 'sun')));
      big.population *= Math.max(0.02, 0.18 - severity * 0.14);
      this.flashes.push({ x: impactX, y: impactY, z: impactZ, r: Math.max(2, big.radius * 1.8), life: 0.7, max: 0.7, color: '#ff9b45' });
      this.flashes.push({ x: impactX, y: impactY, z: impactZ, r: Math.max(1, big.radius * 0.8), life: 0.22, max: 0.22, color: '#fff4cf' });
    }
    if (small.massive) {
      const totalMass = big.mass + small.mass;
      // High-energy impacts eject some material instead of unrealistically converting every
      // collision into a perfectly inelastic, perfectly efficient merger.
      const escapeSpeed = Math.sqrt((2 * G * totalMass) / Math.max(0.5, big.radius + small.radius));
      const hypervelocity = impactSpeed > Math.max(3.5, escapeSpeed * 1.45);
      const ejectaFraction = hypervelocity ? Math.min(0.28, 0.045 + (impactSpeed / Math.max(escapeSpeed, 1)) * 0.035) : 0;
      const retainedMass = Math.max(big.mass * 0.72, totalMass * (1 - ejectaFraction));
      if (!big.dragging) {
        big.vx = (big.vx * big.mass + small.vx * small.mass) / totalMass;
        big.vy = (big.vy * big.mass + small.vy * small.mass) / totalMass;
        big.vz = (big.vz * big.mass + small.vz * small.mass) / totalMass;
        // A small recoil makes violent off-centre impacts visibly perturb the surviving orbit.
        if (hypervelocity && impactSpeed > 0) {
          const recoil = Math.min(0.22, ejectaFraction * impactSpeed / Math.max(escapeSpeed, 1) * 0.18);
          big.vx += ((big.x - small.x) / Math.max(0.001, Math.hypot(big.x - small.x, big.y - small.y, big.z - small.z))) * recoil;
          big.vy += ((big.y - small.y) / Math.max(0.001, Math.hypot(big.x - small.x, big.y - small.y, big.z - small.z))) * recoil;
          big.vz += ((big.z - small.z) / Math.max(0.001, Math.hypot(big.x - small.x, big.y - small.y, big.z - small.z))) * recoil;
        }
      }
      this.setMass(big, retainedMass);
      this.flashes.push({ x: small.x, y: small.y, z: small.z, r: small.radius * (hypervelocity ? 2.2 : 1.5), life: hypervelocity ? 1.5 : 1.2, max: hypervelocity ? 1.5 : 1.2, color: hypervelocity ? '#ffd19a' : small.color });
      if (hypervelocity) {
        const extra = Math.min(90, Math.round(12 + impactSpeed * 5 + small.radius * 8));
        this.explode({ ...small, mass: Math.max(0.001, small.mass * ejectaFraction), radius: Math.max(1, small.radius * 0.7) }, Math.round(extra * (this.simple ? 0.35 : this.ultra ? 1.1 : 0.7)));
        if (big.kind === 'planet' || big.kind === 'moon') {
          big.temperature = Math.min(6000, big.temperature + impactSpeed * 35);
          big.heatBase = Math.max(big.heatBase ?? 0, big.temperature - this.starHeat(big.x, big.y, big.z, this.bodies.filter((x) => x.alive && x.kind === 'sun')));
        }
      }
    }
    const n = small.massive ? Math.min(180, Math.round(18 + small.radius * 14)) : 4;
    this.explode(small, Math.round(n * (big.kind === 'blackhole' ? 0.6 : 1) * (this.simple ? 0.25 : this.ultra ? 1.25 : 0.65)));
    if (small.kind === 'sun') this.supernova(small);
    small.alive = false;
    small.dragging = false;
  }

  /** Capture a slow asteroid that enters a planet's near-gravity zone into a stable moon orbit. */
  private captureNearbyAsteroids() {
    const planets = this.bodies.filter((b) => b.alive && b.kind === 'planet' && !b.dragging);
    if (!planets.length) return;
    const asteroids = this.bodies.filter((b) => b.alive && b.kind === 'asteroid' && !b.dragging);
    for (const a of asteroids) {
      let best: Body | null = null, bestD = Infinity;
      for (const p of planets) {
        const dx = a.x - p.x, dy = a.y - p.y, dz = a.z - p.z;
        const d = Math.hypot(dx, dy, dz);
        const captureR = Math.max(p.radius * 7, Math.min(42, Math.cbrt(p.mass / 0.03) * 12));
        if (d < p.radius + a.radius || d > captureR || d >= bestD) continue;
        const rv = Math.hypot(a.vx - p.vx, a.vy - p.vy, a.vz - p.vz);
        const escape = Math.sqrt((2 * G * p.mass) / Math.max(d, p.radius));
        if (rv > Math.max(1.8, escape * 0.9)) continue;
        best = p; bestD = d;
      }
      if (!best) continue;
      const p = best;
      const dx = a.x - p.x, dz = a.z - p.z;
      const dist = Math.max(p.radius * 2.4, Math.hypot(dx, a.y - p.y, dz));
      const count = this.bodies.filter((b) => b.alive && b.parentId === p.id).length;
      a.kind = 'moon';
      a.name = `${p.name} ${['I', 'II', 'III', 'IV', 'V', 'VI'][count] ?? count + 1}`;
      a.mass = Math.max(a.mass, 0.00008);
      a.baseMass = a.mass;
      a.baseRadius = Math.max(0.45, Math.min(1.1, a.radius));
      a.radius = a.baseRadius;
      a.parentId = p.id;
      a.orbitR = dist / Math.max(0.1, p.radius);
      a.orbitPhase = Math.atan2(dz, dx);
      a.orbitTilt = (Math.random() - 0.5) * 0.35;
      a.orbitSpeed = 1.1 / Math.sqrt(Math.max(1, a.orbitR / 2));
      a.temperature = p.temperature;
      a.trail.length = 0;
      this.flashes.push({ x: a.x, y: a.y, z: a.z, r: a.radius * 2, life: 1.0, max: 1.0, color: '#b9d9ff' });
    }
  }

  /** Equilibrium temperature (°C) from every star, based on distance, star size and star temperature */
  starHeat(x: number, y: number, z: number, suns: Body[]) {
    let t4 = 3 ** 4;
    for (const s of suns) {
      const d = Math.max(s.radius * 1.05, Math.hypot(s.x - x, s.y - y, s.z - z));
      t4 += (0.14 * Math.max(500, s.temperature) * Math.sqrt(s.radius / d)) ** 4;
    }
    return t4 ** 0.25 - 273;
  }

  private updateHeat(dt: number) {
    const suns = this.bodies.filter((b) => b.alive && b.kind === 'sun');
    const k = Math.min(1, dt * 2);
    for (const b of this.bodies) {
      if (!b.alive || (b.kind !== 'planet' && b.kind !== 'moon')) continue;
      const eq = this.starHeat(b.x, b.y, b.z, suns);
      if (b.heatBase == null) b.heatBase = Math.max(-150, Math.min(500, b.temperature - eq));
      const target = Math.max(-270, Math.min(6000, eq + b.heatBase));
      b.temperature += (target - b.temperature) * k;
    }
  }

  private updateLife(dt: number) {
    this.updateHeat(dt);
    const yrs = dt / 62.83;
    for (const b of this.bodies) {
      if (b.kind !== 'planet') continue;
      const cap = b.habitable ? 1e10 * suitability(b.temperature) * Math.cbrt(b.mass / 0.03) : 0;
      if (cap <= 0) { b.population *= Math.exp(-3 * yrs); if (b.population < 1) b.population = 0; continue; }
      if (b.population < 1000) b.population = 1000;
      const rate = b.population > cap ? 2 : 0.6;
      b.population = Math.max(0, b.population + rate * b.population * (1 - b.population / cap) * yrs);
    }
  }

  /** Fragment a body into fast-moving impact ejecta */
  explode(b: Body, n: number) {
    if (this.debris.length + n > MAX_DEBRIS) this.debris.splice(0, this.debris.length + n - MAX_DEBRIS);
    const palette = [b.color, b.color, shade(b.color, 1.5), shade(b.color, 0.55), '#ffd27a', '#ffffff'];
    const base = 2 + Math.sqrt(b.radius) * 2.5;
    for (let i = 0; i < n; i++) {
      const u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2;
      const s = Math.sqrt(1 - u * u);
      const dx = s * Math.cos(th), dy = u, dz = s * Math.sin(th);
      const sp = base * (0.3 + Math.random() * 1.2);
      const off = b.radius * Math.random();
      const life = 2.5 + Math.random() * 5;
      this.debris.push({
        x: b.x + dx * off, y: b.y + dy * off, z: b.z + dz * off,
        vx: b.vx + dx * sp, vy: b.vy + dy * sp, vz: b.vz + dz * sp,
        life, max: life,
        color: palette[(Math.random() * palette.length) | 0],
        size: (0.25 + Math.random() * 0.7) * Math.max(0.6, Math.min(b.radius, 6) / 3),
      });
    }
  }

  destroy(b: Body) {
    this.explode(b, b.kind === 'asteroid' ? 12 : Math.min(600, Math.round(60 + b.radius * 55)));
    this.flashes.push({ x: b.x, y: b.y, z: b.z, r: b.radius * 1.5, life: 1.2, max: 1.2, color: b.color });
    if (b.kind === 'sun') this.supernova(b);
    b.alive = false;
    b.dragging = false;
  }

  /** A shattered sun goes supernova: blinding flashes, a wall of debris and a blast wave that wipes out nearby worlds */
  supernova(b: Body) {
    const maxR = 4000 + b.radius * 180;
    const speed = maxR / 7;
    this.shockwaves.push({ x: b.x, y: b.y, z: b.z, r: b.radius, speed, maxR, color: '#ffb347', sourceId: b.id, hit: new Set() });
    this.flashes.push({ x: b.x, y: b.y, z: b.z, r: b.radius * 18, life: 1.5, max: 1.5, color: '#ffb347' });
    const n = this.simple ? 120 : this.ultra ? 650 : 360;
    if (this.debris.length + n > MAX_DEBRIS) this.debris.splice(0, this.debris.length + n - MAX_DEBRIS);
    const palette = ['#ffffff', '#ffe9a8', '#ffd27a', '#ff9a3d', '#ff5a2a', b.color];
    for (let i = 0; i < n; i++) {
      const u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2;
      const s = Math.sqrt(1 - u * u);
      const dx = s * Math.cos(th), dy = u, dz = s * Math.sin(th);
      const sp = speed * (0.2 + Math.random() * 0.9);
      const off = b.radius * Math.random();
      const life = 3 + Math.random() * 6;
      this.debris.push({
        x: b.x + dx * off, y: b.y + dy * off, z: b.z + dz * off,
        vx: dx * sp, vy: dy * sp, vz: dz * sp,
        life, max: life,
        color: palette[(Math.random() * palette.length) | 0],
        size: 0.7 + Math.random() * 1.8,
      });
    }
  }

  private updateShockwaves(dt: number) {
    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const w = this.shockwaves[i];
      w.r += w.speed * dt;
      for (const t of this.bodies) {
        if (!t.alive || t.id === w.sourceId || w.hit.has(t.id)) continue;
        const d = Math.hypot(t.x - w.x, t.y - w.y, t.z - w.z);
        if (d > w.r) continue;
        w.hit.add(t.id);
        if (t.kind === 'planet' || t.kind === 'moon' || t.kind === 'asteroid') {
          this.destroy(t);
        } else if (t.kind === 'sun' && !t.dragging && d > 0) {
          const k = 3 * (1 - Math.min(1, d / w.maxR));
          t.vx += ((t.x - w.x) / d) * k; t.vy += ((t.y - w.y) / d) * k; t.vz += ((t.z - w.z) / d) * k;
        }
      }
      if (w.r >= w.maxR) this.shockwaves.splice(i, 1);
    }
  }

  private updateDebris(dt: number) {
    const heavy = this.bodies.filter((b) => b.alive && b.massive && b.mass > 1);
    const arr = this.debris;
    for (let i = arr.length - 1; i >= 0; i--) {
      const d = arr[i];
      d.life -= dt;
      let dead = d.life <= 0;
      if (!dead) {
        for (const m of heavy) {
          const dx = m.x - d.x, dy = m.y - d.y, dz = m.z - d.z;
          const r2 = dx * dx + dy * dy + dz * dz + EPS2;
          if ((m.kind === 'sun' || m.kind === 'blackhole') && r2 < m.radius * m.radius) { dead = true; break; }
          const inv = (G * m.mass * dt) / (r2 * Math.sqrt(r2));
          d.vx += dx * inv; d.vy += dy * inv; d.vz += dz * inv;
        }
        d.x += d.vx * dt; d.y += d.vy * dt; d.z += d.vz * dt;
      }
      if (dead) { arr[i] = arr[arr.length - 1]; arr.pop(); }
    }
  }

  /** Simulates the massive bodies (plus extras) forward and returns their future paths */
  predict(horizon: number, extra: Set<number>): Map<number, Float32Array> {
    const list = this.bodies.filter((b) => b.alive && b.parentId == null && (b.massive || extra.has(b.id)));
    const n = list.length;
    const px = new Float64Array(n), py = new Float64Array(n), pz = new Float64Array(n);
    const vx = new Float64Array(n), vy = new Float64Array(n), vz = new Float64Array(n);
    const dead = new Uint8Array(n);
    list.forEach((b, i) => { px[i] = b.x; py[i] = b.y; pz[i] = b.z; vx[i] = b.vx; vy[i] = b.vy; vz[i] = b.vz; });
    const h = Math.max(0.04, horizon / 2500);
    const steps = Math.min(this.simple ? 900 : this.ultra ? 3200 : 2500, Math.ceil(horizon / h));
    const rec = Math.max(1, Math.floor(steps / (this.simple ? 90 : this.ultra ? 300 : 240)));
    const cap = Math.floor(steps / rec) + 2;
    const out = list.map(() => new Float32Array(cap * 3));
    const counts = new Int32Array(n);
    const record = (i: number) => {
      const c = counts[i];
      if (c >= cap) return;
      out[i][c * 3] = px[i]; out[i][c * 3 + 1] = py[i]; out[i][c * 3 + 2] = pz[i];
      counts[i] = c + 1;
    };
    for (let i = 0; i < n; i++) record(i);
    for (let s = 1; s <= steps; s++) {
      for (let i = 0; i < n; i++) {
        if (dead[i]) continue;
        let ax = 0, ay = 0, az = 0;
        for (let j = 0; j < n; j++) {
          if (j === i || dead[j] || !list[j].massive) continue;
          const dx = px[j] - px[i], dy = py[j] - py[i], dz = pz[j] - pz[i];
          const r2 = dx * dx + dy * dy + dz * dz + EPS2;
          const inv = (G * list[j].mass) / (r2 * Math.sqrt(r2));
          ax += dx * inv; ay += dy * inv; az += dz * inv;
        }
        vx[i] += ax * h; vy[i] += ay * h; vz[i] += az * h;
      }
      for (let i = 0; i < n; i++) {
        if (dead[i]) continue;
        px[i] += vx[i] * h; py[i] += vy[i] * h; pz[i] += vz[i] * h;
      }
      for (let i = 0; i < n; i++) {
        if (dead[i]) continue;
        for (let j = 0; j < n; j++) {
          if (j === i || dead[j] || !list[j].massive) continue;
          if (rank(list[j]) < rank(list[i]) || (rank(list[j]) === rank(list[i]) && list[j].mass <= list[i].mass)) continue;
          const dx = px[j] - px[i], dy = py[j] - py[i], dz = pz[j] - pz[i];
          const rr = list[i].radius + list[j].radius;
          if (dx * dx + dy * dy + dz * dz < rr * rr) { record(i); dead[i] = 1; break; }
        }
      }
      if (s % rec === 0) for (let i = 0; i < n; i++) if (!dead[i]) record(i);
    }
    const map = new Map<number, Float32Array>();
    list.forEach((b, i) => map.set(b.id, out[i].subarray(0, counts[i] * 3)));
    return map;
  }
}
