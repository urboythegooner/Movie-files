import type { Sim } from './sim';

type Ctx = CanvasRenderingContext2D;

/** Deep space: thousands of far-off suns and whole spiral galaxies, placed in real 3D so they only
 *  come into view (and drift past) as you zoom way, way out. */

function rng(seed: number) {
  return () => {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface FarStar { x: number; y: number; z: number; c: string; b: number; s: number }
interface Galaxy { cx: number; cy: number; cz: number; R: number; rgb: string; pts: Float32Array }

const rand = rng(20261009);
const STAR_COLORS = ['#ffffff', '#cfe0ff', '#ffe9b8', '#ffb38a', '#9db8ff'];
const GALAXY_COLORS = ['180,200,255', '255,210,160', '220,170,255', '160,255,230', '255,170,170'];

function dir() {
  const u = rand() * 2 - 1, th = rand() * Math.PI * 2, s = Math.sqrt(1 - u * u);
  return [s * Math.cos(th), u, s * Math.sin(th)];
}

const farStars: FarStar[] = Array.from({ length: 12000 }, () => {
  const d = 6000 * Math.pow(420000, rand()); // 6,000 … 2,520,000,000 units out, covering the extreme deep-zoom range
  const [x, y, z] = dir();
  const roll = rand();
  return { x: x * d, y: y * d, z: z * d, c: STAR_COLORS[(rand() * STAR_COLORS.length) | 0], b: 0.35 + rand() * 0.65, s: roll < 0.06 ? 2.6 : roll < 0.4 ? 1.7 : 1.1 };
});

const galaxies: Galaxy[] = Array.from({ length: 28 }, (_, gi) => {
  // Distant galaxies span from the nearby galactic neighborhood to the visible-universe boundary.
  const d = 250000 + Math.pow(rand(), 1.7) * 1800000000;
  const [dx, dy, dz] = dir();
  const R = Math.max(40000, d * (0.00012 + rand() * 0.00016));
  const tilt = rand() * Math.PI, yaw = rand() * Math.PI * 2;
  const ct = Math.cos(tilt), st = Math.sin(tilt), cy = Math.cos(yaw), sy = Math.sin(yaw);
  const N = 900;
  const pts = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) {
    const t = Math.pow(rand(), 0.8);
    const ang = (i % 2) * Math.PI + t * 5.5 + (rand() - 0.5) * 0.6;
    const rad = R * t;
    let lx = rad * Math.cos(ang), ly = (rand() - 0.5) * R * 0.07 * (1 - t), lz = rad * Math.sin(ang);
    const y1 = ly * ct - lz * st, z1 = ly * st + lz * ct;
    const x2 = lx * cy + z1 * sy, z2 = -lx * sy + z1 * cy;
    lx = x2; ly = y1;
    pts[i * 3] = lx; pts[i * 3 + 1] = ly; pts[i * 3 + 2] = z2;
  }
  return { cx: dx * d, cy: dy * d, cz: dz * d, R, rgb: GALAXY_COLORS[gi % GALAXY_COLORS.length], pts };
});

export function drawDeepSpace(ctx: Ctx, sim: Sim, w: number, h: number, simple: boolean) {
  const cam = sim.camera;
  const fade = Math.min(1, Math.max(0, (cam.dist - 1500) / 6000));
  if (fade <= 0.01) return;
  ctx.globalCompositeOperation = 'lighter';

  // Keep galaxy detail visible at the new deep-universe zoom levels.
  const gfade = Math.min(0.65, Math.max(0, (cam.dist - 15000) / 6000000) * 0.65);
  if (gfade > 0.01 && !simple) {
    for (const g of galaxies) {
      const z = cam.project(g.cx, g.cy, g.cz);
      if (z < 0) continue;
      const gx = cam.sx, gy = cam.sy;
      const rs = Math.min(3000, (g.R * cam.F) / z);
      if (gx < -rs || gy < -rs || gx > w + rs || gy > h + rs) continue;
      const glow = Math.max(3, rs);
      const grad = ctx.createRadialGradient(gx, gy, 0, gx, gy, glow);
      grad.addColorStop(0, `rgba(255,245,225,${0.9 * gfade})`);
      grad.addColorStop(0.15, `rgba(${g.rgb},${0.35 * gfade})`);
      grad.addColorStop(1, `rgba(${g.rgb},0)`);
      ctx.globalAlpha = 1;
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.arc(gx, gy, glow, 0, Math.PI * 2); ctx.fill();
      if (rs > 8) {
        ctx.fillStyle = `rgb(${g.rgb})`;
        ctx.globalAlpha = 0.55 * gfade;
        const p = g.pts;
        for (let i = 0; i < p.length; i += 3) {
          if (cam.project(g.cx + p[i], g.cy + p[i + 1], g.cz + p[i + 2]) < 0) continue;
          ctx.fillRect(cam.sx - 1, cam.sy - 1, 2, 2);
        }
      }
    }
  }

  const count = simple ? 1800 : farStars.length;
  for (let i = 0; i < count; i++) {
    const s = farStars[i];
    if (cam.project(s.x, s.y, s.z) < 0) continue;
    const sx = cam.sx, sy = cam.sy;
    if (sx < 0 || sy < 0 || sx > w || sy > h) continue;
    ctx.fillStyle = s.c;
    ctx.globalAlpha = s.b * fade;
    ctx.fillRect(sx - s.s / 2, sy - s.s / 2, s.s, s.s);
    if (s.s > 2) {
      ctx.globalAlpha = s.b * fade * 0.2;
      ctx.fillRect(sx - s.s * 1.5, sy - s.s * 1.5, s.s * 3, s.s * 3);
    }
  }
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = 'source-over';
}
