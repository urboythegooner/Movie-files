import type { Sim } from './sim';

export type SaveData = ReturnType<Sim['serialize']>;
export interface SaveMeta { id: string; name: string; savedAt: number; bodies: number; ultra: boolean }

const INDEX = 'solarpixel:saves';
const key = (id: string) => `solarpixel:save:${id}`;

export function listSaves(): SaveMeta[] {
  try { return (JSON.parse(localStorage.getItem(INDEX) || '[]') as SaveMeta[]).sort((a, b) => b.savedAt - a.savedAt); }
  catch { return []; }
}

export function writeSave(name: string, data: SaveData, id?: string): SaveMeta {
  const meta: SaveMeta = { id: id ?? crypto.randomUUID(), name, savedAt: Date.now(), bodies: data.bodies.length, ultra: data.ultra };
  localStorage.setItem(key(meta.id), JSON.stringify(data));
  localStorage.setItem(INDEX, JSON.stringify([meta, ...listSaves().filter((s) => s.id !== meta.id)]));
  return meta;
}

export function readSave(id: string): SaveData | null {
  try { return JSON.parse(localStorage.getItem(key(id)) || 'null'); } catch { return null; }
}

export function deleteSave(id: string) {
  localStorage.removeItem(key(id));
  localStorage.setItem(INDEX, JSON.stringify(listSaves().filter((s) => s.id !== id)));
}

export interface Prefs { mode: 'normal' | 'simple' | 'ultra'; prediction: boolean; trails: boolean; labels: boolean; orbitAssist: boolean }
const PREFS = 'solarpixel:prefs';
export const defaultPrefs: Prefs = { mode: 'normal', prediction: true, trails: true, labels: true, orbitAssist: true };
export function loadPrefs(): Prefs {
  try { return { ...defaultPrefs, ...JSON.parse(localStorage.getItem(PREFS) || '{}') }; } catch { return defaultPrefs; }
}
export function savePrefs(p: Prefs) { localStorage.setItem(PREFS, JSON.stringify(p)); }
