import { Body } from './engine';
import { Sim } from './sim';
import { atmosphereFor, drawSurface } from './surface';
import { drawCityLights, drawFineBands, drawNebulae, drawRingsUltra, drawSunGranules, drawSunUltra } from './ultra';

import * as U2 from './ultra2';
import * as U3 from './ultra3';
import * as U4 from './ultra4';
import { drawFleet, drawHeat } from './fleetRender';
import { drawDeepSpace } from './deepspace';

type Ctx = CanvasRenderingContext2D;
let lastT = 0;

export function render(ctx: Ctx, sim: Sim, w: number, h: number, t: number) {
  const cam = sim.camera, world = sim.world;
  ctx.fillStyle = '#02030a';
  ctx.fillRect(0, 0, w, h);
  const simple = sim.settings.simple, ultra = sim.settings.ultra;
  const fdt = Math.min(0.05, Math.max(0, t - lastT)); lastT = t;
  if (ultra) {
    drawUltraBackground(ctx, sim, w, h);
    U2.drawShootingStars(ctx, w, h, fdt);
  } else drawStars(ctx, sim, w, h, t, simple ? 350 : 1600);
  drawDeepSpace(ctx, sim, w, h, simple);
  const byId = new Map(world.bodies.map((b) => [b.id, b]));
  if (sim.settings.trails && !simple) drawTrails(ctx, sim);
  if (sim.settings.prediction) drawPrediction(ctx, sim, byId);

  const sun = world.bodies.find((b) => b.kind === 'sun');
  let lsx = cam.cx, lsy = cam.cy;
  if (sun && cam.project(sun.x, sun.y, sun.z) > 0) { lsx = cam.sx; lsy = cam.sy; }

  if (ultra) {
    U3.drawSpacetimeGrid(ctx, sim, sun);
    U3.drawZones(ctx, sim, sun);
    U3.drawMoonOrbits(ctx, sim);
    U4.drawLagrange(ctx, sim, t);
    U2.drawSolarWind(ctx, sim, sun, sim.settings.paused ? 0 : fdt * sim.settings.timeScale * (sim.settings.slow ? 0.15 : 1));
    U2.drawCometTails(ctx, sim, sun);
  }
  // Small bodies and impact ejecta are drawn in one fast pass for performance
  const F = cam.F;
  for (const b of world.bodies) {
    if (b.kind !== 'asteroid') continue;
    const z = cam.project(b.x, b.y, b.z);
    if (z < 0 || cam.sx < 0 || cam.sy < 0 || cam.sx > w || cam.sy > h) continue;
    const projected = (b.radius * 2 * F) / z;
    if (projected < 0.55) continue;
    const s = Math.max(0.8, projected);
    if (ultra && s > 3) { U3.drawRock(ctx, b, cam.sx, cam.sy, s, t); continue; }
    ctx.fillStyle = b.color;
    ctx.beginPath(); ctx.arc(cam.sx, cam.sy, s * 0.5, 0, Math.PI * 2); ctx.fill();
    if (s > 2.2) {
      const rockShade = ctx.createRadialGradient(cam.sx - s * 0.2, cam.sy - s * 0.22, 0.2, cam.sx, cam.sy, s * 0.58);
      rockShade.addColorStop(0, 'rgba(255,255,255,0.24)');
      rockShade.addColorStop(0.55, 'rgba(0,0,0,0)');
      rockShade.addColorStop(1, 'rgba(0,0,0,0.5)');
      ctx.fillStyle = rockShade;
      ctx.beginPath(); ctx.arc(cam.sx, cam.sy, s * 0.5, 0, Math.PI * 2); ctx.fill();
    }
  }
  if (ultra) ctx.globalCompositeOperation = 'lighter';
  const streaks = ultra && world.debris.length < 2500;
  for (const d of world.debris) {
    const z = cam.project(d.x, d.y, d.z);
    if (z < 0 || cam.sx < 0 || cam.sy < 0 || cam.sx > w || cam.sy > h) continue;
    const s = Math.max(1.5, (d.size * F) / z);
    ctx.globalAlpha = Math.min(1, (d.life / d.max) * 1.6);
    ctx.fillStyle = d.color;
    ctx.beginPath(); ctx.arc(cam.sx, cam.sy, s * 0.5, 0, Math.PI * 2); ctx.fill();
    if (ultra && s > 2.4) {
      ctx.globalAlpha *= 0.16;
      ctx.beginPath(); ctx.arc(cam.sx, cam.sy, s * 1.9, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = Math.min(1, (d.life / d.max) * 1.6);
    }
    if (streaks && d.life > d.max * 0.5 && s > 1.2) {
      const x0 = cam.sx, y0 = cam.sy;
      if (cam.project(d.x - d.vx * 0.25, d.y - d.vy * 0.25, d.z - d.vz * 0.25) > 0) {
        ctx.strokeStyle = d.color; ctx.lineWidth = Math.max(1, s * 0.6); ctx.globalAlpha *= 0.5;
        ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(cam.sx, cam.sy); ctx.stroke();
      }
    }
  }
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = 'source-over';

  const list: { z: number; b: Body; sx: number; sy: number }[] = [];
  for (const b of world.bodies) {
    if (b.kind === 'asteroid') continue;
    const z = cam.project(b.x, b.y, b.z);
    if (z < 0) continue;
    const r = (b.radius * F) / z * (b.kind === 'sun' ? 5 : 3) + 4;
    if (cam.sx < -r || cam.sy < -r || cam.sx > w + r || cam.sy > h + r) continue;
    list.push({ z, b, sx: cam.sx, sy: cam.sy });
  }
  list.sort((a, b) => b.z - a.z);
  for (const it of list) drawBody(ctx, sim, it.b, it.sx, it.sy, it.z, lsx, lsy, t);
  ctx.globalAlpha = 1;

  drawShockwaves(ctx, sim);

  for (const f of world.flashes) {
    const z = cam.project(f.x, f.y, f.z);
    if (z < 0) continue;
    const k = 1 - f.life / f.max;
    if (ultra) U2.drawImpactGlow(ctx, cam.sx, cam.sy, Math.max(10, ((f.r * cam.F) / z) * (2 + k * 6)), (1 - k) * 0.7, f.color);
    ctx.strokeStyle = f.color;
    ctx.globalAlpha = (1 - k) * 0.8;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cam.sx, cam.sy, Math.max(4, ((f.r * cam.F) / z) * (1 + k * 5)), 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  if (sim.settings.travel) drawFleet(ctx, sim, t);
  if (ultra) { U4.drawReticle(ctx, sim, t); U4.drawDust(ctx, sim, w, h); }
  if (ultra) { U3.drawMotes(ctx, sim, t); U2.drawLensFlare(ctx, sim, sun, w, h); U2.drawVignette(ctx, w, h); U3.drawScanlines(ctx, w, h); U3.drawVelocityArrow(ctx, sim); }
  drawOverlays(ctx, sim);
}

/** Supernova blast fronts: a glowing expanding shell plus a white-out flash at the start */
function drawShockwaves(ctx: Ctx, sim: Sim) {
  const cam = sim.camera;
  for (const sw of sim.world.shockwaves) {
    const z = cam.project(sw.x, sw.y, sw.z);
    if (z < 0) continue;
    const sx = cam.sx, sy = cam.sy;
    const k = Math.min(1, sw.r / sw.maxR);
    const a = Math.max(0, 1 - k);
    const rs = Math.min(60000, (sw.r * cam.F) / z);
    ctx.globalCompositeOperation = 'lighter';
    if (rs > 2 && rs < 8000) {
      const g = ctx.createRadialGradient(sx, sy, rs * 0.72, sx, sy, rs);
      g.addColorStop(0, 'rgba(255,140,40,0)');
      g.addColorStop(0.9, `rgba(255,150,50,${0.14 * a})`);
      g.addColorStop(1, `rgba(255,205,130,${0.34 * a})`);
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(sx, sy, rs, 0, Math.PI * 2); ctx.fill();
    }
    const lw = Math.min(36, Math.max(1.5, (sw.r * 0.025 * cam.F) / z));
    ctx.strokeStyle = `rgba(255,145,65,${0.6 * a})`;
    ctx.lineWidth = lw;
    ctx.beginPath(); ctx.arc(sx, sy, Math.max(2, rs), 0, Math.PI * 2); ctx.stroke();
  }
  ctx.globalCompositeOperation = 'source-over';
  ctx.globalAlpha = 1;
}

// The far background (nebulae, galaxies, stars, constellations, Oort cloud) only depends on
// where the camera points, so it's painted to an offscreen canvas and reused until the view turns.
let bg: HTMLCanvasElement | null = null;
let bgKey = '';
function drawUltraBackground(ctx: Ctx, sim: Sim, w: number, h: number) {
  const c = sim.camera;
  const key = [c.fx, c.fy, c.fz, c.F].map((v) => v.toFixed(3)).join(',') + w + 'x' + h;
  if (!bg) bg = document.createElement('canvas');
  if (key !== bgKey) {
    bgKey = key;
    if (bg.width !== w || bg.height !== h) { bg.width = w; bg.height = h; }
    const b = bg.getContext('2d')!;
    b.clearRect(0, 0, w, h);
    drawNebulae(b, sim, w, h);
    U2.drawGalaxies(b, sim, w, h);
    drawStars(b, sim, w, h, 0, sim.stars.length);
    U3.drawStarDetails(b, sim, w, h);
    U3.drawOort(b, sim);
  }
  ctx.drawImage(bg, 0, 0, w, h);
}

function drawStars(ctx: Ctx, sim: Sim, w: number, h: number, t: number, count: number) {
  const c = sim.camera;
  for (let i = 0; i < count; i++) {
    const s = sim.stars[i];
    const zc = s.x * c.fx + s.y * c.fy + s.z * c.fz;
    if (zc <= 0.05) continue;
    const sx = c.cx + ((s.x * c.rx + s.y * c.ry + s.z * c.rz) * c.F) / zc;
    const sy = c.cy - ((s.x * c.ux + s.y * c.uy + s.z * c.uz) * c.F) / zc;
    if (sx < 0 || sy < 0 || sx > w || sy > h) continue;
    ctx.globalAlpha = s.b * (0.7 + 0.3 * Math.sin(t * s.tw + s.ph));
    ctx.fillStyle = s.c;
    ctx.fillRect(sx, sy, s.s, s.s);
  }
  ctx.globalAlpha = 1;
}

function strokePath(ctx: Ctx, sim: Sim, pts: ArrayLike<number>, maxAlpha: number, fadeIn: boolean, tail?: [number, number, number]) {
  const cam = sim.camera;
  const n = Math.floor(pts.length / 3) + (tail ? 1 : 0);
  if (n < 2) return;
  const coord = (i: number, axis: number) => i === n - 1 && tail ? tail[axis] : pts[i * 3 + axis];
  const chunks = 8, size = Math.ceil(n / chunks);
  for (let c = 0; c < chunks; c++) {
    const k = fadeIn ? (c + 1) / chunks : 1 - c / chunks;
    ctx.globalAlpha = maxAlpha * k;
    ctx.beginPath();
    let pen = false;
    for (let i = c * size; i <= Math.min(n - 1, (c + 1) * size); i++) {
      if (cam.project(coord(i, 0), coord(i, 1), coord(i, 2)) < 0) { pen = false; continue; }
      if (pen) ctx.lineTo(cam.sx, cam.sy); else ctx.moveTo(cam.sx, cam.sy);
      pen = true;
    }
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
}

function drawTrails(ctx: Ctx, sim: Sim) {
  ctx.lineWidth = 1;
  ctx.setLineDash([]);
  for (const b of sim.world.bodies) {
    if (b.trail.length < 6) continue;
    ctx.strokeStyle = b.kind === 'blackhole' ? '#c58bff' : b.color;
    strokePath(ctx, sim, b.trail, sim.settings.ultra ? 0.6 : 0.4, true, [b.x, b.y, b.z]);
  }
}

function drawPrediction(ctx: Ctx, sim: Sim, byId: Map<number, Body>) {
  const cam = sim.camera;
  for (const [id, pts] of sim.prediction) {
    const b = byId.get(id);
    if (!b || b.kind === 'sun') continue;
    const sel = id === sim.selectedId;
    ctx.strokeStyle = b.kind === 'blackhole' ? '#c58bff' : b.color;
    ctx.lineWidth = sel ? 2 : 1.2;
    ctx.setLineDash([4, 5]);
    strokePath(ctx, sim, pts, sel ? 1 : 0.75, false);
    const n = pts.length / 3;
    if (n > 1 && cam.project(pts[(n - 1) * 3], pts[(n - 1) * 3 + 1], pts[(n - 1) * 3 + 2]) > 0) {
      ctx.setLineDash([]);
      ctx.globalAlpha = 0.6;
      ctx.beginPath();
      ctx.arc(cam.sx, cam.sy, 3, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
  }
  ctx.setLineDash([]);
}

function drawRing(ctx: Ctx, sim: Sim, b: Body, zCenter: number, back: boolean) {
  const cam = sim.camera;
  const tilt = 0.47, R = b.radius * 1.9, N = 48;
  const pts: number[] = [];
  for (let i = 0; i <= N; i++) {
    const a = (i / N) * Math.PI * 2;
    const z = cam.project(b.x + Math.cos(a) * R, b.y + Math.sin(a) * Math.sin(tilt) * R, b.z + Math.sin(a) * Math.cos(tilt) * R);
    pts.push(cam.sx, cam.sy, z);
  }
  ctx.strokeStyle = 'rgba(222,200,150,0.6)';
  ctx.lineWidth = Math.max(1, ((b.radius * 0.6) * cam.F) / zCenter);
  ctx.beginPath();
  for (let i = 0; i < N; i++) {
    const z1 = pts[i * 3 + 2], z2 = pts[i * 3 + 5];
    if (z1 < 0 || z2 < 0) continue;
    if ((z1 + z2) / 2 > zCenter !== back) continue;
    ctx.moveTo(pts[i * 3], pts[i * 3 + 1]);
    ctx.lineTo(pts[i * 3 + 3], pts[i * 3 + 4]);
  }
  ctx.stroke();
}

function drawBody(ctx: Ctx, sim: Sim, b: Body, sx: number, sy: number, z: number, lsx: number, lsy: number, t: number) {
  const r = (b.radius * sim.camera.F) / z;
  if (b.kind === 'asteroid') {
    const s = Math.max(1.3, r * 2);
    ctx.fillStyle = b.color;
    ctx.beginPath(); ctx.arc(sx, sy, s / 2, 0, Math.PI * 2); ctx.fill();
    if (s > 2.2) {
      const rockShade = ctx.createRadialGradient(sx - s * 0.18, sy - s * 0.2, 0.2, sx, sy, s * 0.58);
      rockShade.addColorStop(0, 'rgba(255,255,255,0.2)'); rockShade.addColorStop(0.55, 'rgba(0,0,0,0)'); rockShade.addColorStop(1, 'rgba(0,0,0,0.48)');
      ctx.fillStyle = rockShade; ctx.beginPath(); ctx.arc(sx, sy, s / 2, 0, Math.PI * 2); ctx.fill();
    }
    return;
  }
  const simple = sim.settings.simple;
  if (simple) {
    ctx.fillStyle = b.kind === 'blackhole' ? '#000' : b.color;
    ctx.beginPath(); ctx.arc(sx, sy, Math.max(r, 1.5), 0, Math.PI * 2); ctx.fill();
    if (b.kind === 'blackhole') { ctx.strokeStyle = '#ff9a4a'; ctx.lineWidth = 1.5; ctx.stroke(); }
    return;
  }
  const ultra = sim.settings.ultra;
  if (b.kind === 'sun') {
    if (ultra) { drawSunUltra(ctx, sx, sy, Math.max(r, 2), t); U4.drawCorona(ctx, sx, sy, r, t, b.color); }
    const g = ctx.createRadialGradient(sx, sy, r * 0.6, sx, sy, r * 5);
    g.addColorStop(0, 'rgba(255,200,100,0.5)');
    g.addColorStop(0.35, 'rgba(255,130,40,0.14)');
    g.addColorStop(1, 'rgba(255,100,30,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(sx, sy, r * 5, 0, Math.PI * 2); ctx.fill();
    const d = ctx.createRadialGradient(sx, sy, 0, sx, sy, r);
    if (b.name === 'Sun') { d.addColorStop(0, '#fffbe6'); d.addColorStop(0.55, '#ffd55a'); d.addColorStop(1, '#ff9a2e'); }
    else { d.addColorStop(0, '#ffffff'); d.addColorStop(0.5, b.color); d.addColorStop(1, b.color); }
    ctx.fillStyle = d;
    ctx.beginPath(); ctx.arc(sx, sy, Math.max(r, 2), 0, Math.PI * 2); ctx.fill();
    if (ultra) { drawSunGranules(ctx, sx, sy, r, t); U3.drawSunspots(ctx, sx, sy, r, t); U2.drawProminences(ctx, sx, sy, r, t); U3.drawCMEs(ctx, sx, sy, Math.max(r, 2), sim.settings.paused ? 0 : 1 / 60); }
    return;
  }
  if (b.kind === 'blackhole') {
    const rr = Math.max(r, 2.5);
    const g = ctx.createRadialGradient(sx, sy, rr, sx, sy, rr * 3.2);
    g.addColorStop(0, 'rgba(255,210,140,0.95)');
    g.addColorStop(0.18, 'rgba(255,120,50,0.55)');
    g.addColorStop(0.6, 'rgba(150,60,200,0.15)');
    g.addColorStop(1, 'rgba(120,40,160,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(sx, sy, rr * 3.2, 0, Math.PI * 2); ctx.fill();
    if (ultra) { U3.drawBlackHoleExtras(ctx, sx, sy, rr, t); U2.drawAccretionDisk(ctx, sx, sy, rr, t, false); }
    ctx.fillStyle = '#000';
    ctx.beginPath(); ctx.arc(sx, sy, rr, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(255,230,180,0.85)'; ctx.lineWidth = 1.2; ctx.stroke();
    if (ultra) { U2.drawAccretionDisk(ctx, sx, sy, rr, t, true); U4.drawEinsteinRing(ctx, sx, sy, rr, t); }
    return;
  }
  if (r < 1.6) {
    const s = Math.max(2, r * 2);
    ctx.fillStyle = b.color;
    ctx.fillRect(sx - s / 2, sy - s / 2, s, s);
    return;
  }
  const ultraRing = ultra && (b.ring || b.name === 'Uranus' || b.name === 'Jupiter');
  if (ultraRing) drawRingsUltra(ctx, sim, b, z, true);
  else if (b.ring) drawRing(ctx, sim, b, z, true);
  const lx = lsx - sx, ly = lsy - sy, l = Math.hypot(lx, ly) || 1;
  const atmo = atmosphereFor(b);
  if (atmo && r > 3) {
    const a = ctx.createRadialGradient(sx, sy, r * 0.9, sx, sy, r * 1.35);
    a.addColorStop(0, atmo); a.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = a;
    ctx.beginPath(); ctx.arc(sx, sy, r * 1.35, 0, Math.PI * 2); ctx.fill();
  }
  ctx.fillStyle = b.color;
  ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.fill();
  if (r > 5 && (b.kind === 'planet' || (ultra && b.kind === 'moon'))) {
    const cam = sim.camera;
    const viewLon = Math.atan2(cam.pz - b.z, cam.px - b.x);
    const viewLat = Math.atan2(cam.py - b.y, Math.hypot(cam.px - b.x, cam.pz - b.z));
    drawSurface(ctx, b, sx, sy, r, t, viewLon, viewLat);
  }
  if (ultra && r > 8 && b.kind === 'planet') drawFineBands(ctx, b, sx, sy, r, t);
  const g = ctx.createRadialGradient(sx + (lx / l) * r * 0.45, sy + (ly / l) * r * 0.45, r * 0.1, sx, sy, r * 1.05);
  g.addColorStop(0, 'rgba(255,255,255,0.28)');
  g.addColorStop(0.45, 'rgba(0,0,0,0)');
  g.addColorStop(1, 'rgba(0,0,0,0.88)');
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.fill();
  drawHeat(ctx, b.temperature, sx, sy, r, t);
  if (ultra) {
    drawCityLights(ctx, b, sx, sy, r, t, lx / l, ly / l);
    U4.drawPlanetDetail(ctx, b, sx, sy, r, t, lx / l, ly / l);
    U3.drawPlanetMaterial(ctx, b, sx, sy, r, lx / l, ly / l);
    if (b.kind === 'planet') { U3.drawRadiationBelts(ctx, sim, b, z); U2.drawPlanetExtras(ctx, b, sx, sy, r, t, lx / l, ly / l); U2.drawSatellites(ctx, sim, b, t); }
  }
  if (ultraRing) drawRingsUltra(ctx, sim, b, z, false);
  else if (b.ring) drawRing(ctx, sim, b, z, false);
  if (b.habitable && r > 3) {
    ctx.strokeStyle = 'rgba(110,240,160,0.45)'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(sx, sy, r + 2.5, 0, Math.PI * 2); ctx.stroke();
  }
}

function drawOverlays(ctx: Ctx, sim: Sim) {
  const cam = sim.camera;
  ctx.font = '10px "JetBrains Mono", monospace';
  ctx.textAlign = 'center';
  for (const b of sim.world.bodies) {
    const sel = b.id === sim.selectedId, hov = b.id === sim.hoverId;
    const showLabel = sim.settings.labels && (b.kind !== 'asteroid' || (b.name !== 'Asteroid' && b.name !== 'Kuiper Object')) && (b.kind !== 'moon' || (b.radius * cam.F) / Math.max(1, cam.project(b.x, b.y, b.z)) > 1.5);
    if (!sel && !hov && !showLabel) continue;
    const z = cam.project(b.x, b.y, b.z);
    if (z < 0) continue;
    const r = Math.max((b.radius * cam.F) / z, 2);
    if (sel) {
      const s = r + 7, k = Math.max(4, s * 0.4);
      ctx.strokeStyle = '#ffc04d'; ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (const [dx, dy] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
        const x = cam.sx + dx * s, y = cam.sy + dy * s;
        ctx.moveTo(x, y - dy * k); ctx.lineTo(x, y); ctx.lineTo(x - dx * k, y);
      }
      ctx.stroke();
    } else if (hov) {
      ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(cam.sx, cam.sy, r + 5, 0, Math.PI * 2); ctx.stroke();
    }
    if (showLabel || sel) {
      ctx.fillStyle = sel ? '#ffc04d' : 'rgba(220,228,255,0.75)';
      ctx.fillText(b.name.toUpperCase(), cam.sx, cam.sy - r - (sel ? 12 : 6));
      if ((b.kind === 'planet' || (b.kind === 'moon' && sel)) && !sim.settings.simple) {
        const T = Math.round(b.temperature);
        ctx.fillStyle = T > 300 ? '#ff5a3a' : T > 60 ? '#ffb347' : T < -100 ? '#7cc8ff' : T < 0 ? '#bfe4ff' : '#8dffb0';
        ctx.fillText(`${T}°C`, cam.sx, cam.sy - r - (sel ? 22 : 16));
      }
    }
  }
}
