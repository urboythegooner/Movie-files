import { Body } from './engine';
import { shade } from './colors';

type Ctx = CanvasRenderingContext2D;

interface Spot { lon: number; lat: number; size: number; color: string; stretch?: number }
interface Look { bands?: [number, number, string][]; spots?: Spot[]; caps?: string; clouds?: boolean; atmo?: string; spin: number }

const deg = Math.PI / 180;

const LOOKS: Record<string, Look> = {
  Mercury: { spin: 0.05, spots: [
    { lon: 0, lat: 20 * deg, size: 0.18, color: '#7d766c' }, { lon: 70 * deg, lat: -30 * deg, size: 0.12, color: '#8a8378' },
    { lon: 150 * deg, lat: 10 * deg, size: 0.22, color: '#857e74' }, { lon: 230 * deg, lat: -10 * deg, size: 0.1, color: '#6f695f' },
    { lon: 300 * deg, lat: 40 * deg, size: 0.14, color: '#7a7369' },
  ] },
  Venus: { spin: -0.02, atmo: 'rgba(255,220,150,0.5)', bands: [[-0.5, 0.15, 'rgba(255,240,200,0.25)'], [0.1, 0.2, 'rgba(200,150,80,0.25)'], [0.55, 0.12, 'rgba(255,235,190,0.2)']] },
  Earth: { spin: 0.6, atmo: 'rgba(120,180,255,0.6)', caps: '#f2f6ff', clouds: true, spots: [
    { lon: 0, lat: 15 * deg, size: 0.32, color: '#3f9a4a', stretch: 1.6 }, { lon: 30 * deg, lat: -20 * deg, size: 0.22, color: '#c9a65a' },
    { lon: 110 * deg, lat: 35 * deg, size: 0.38, color: '#4a9a50', stretch: 1.8 }, { lon: 200 * deg, lat: -25 * deg, size: 0.2, color: '#c79a52' },
    { lon: 260 * deg, lat: 30 * deg, size: 0.3, color: '#3d8f46', stretch: 1.3 }, { lon: 280 * deg, lat: -15 * deg, size: 0.22, color: '#479c4c' },
  ] },
  Mars: { spin: 0.58, caps: '#f5ece4', spots: [
    { lon: 40 * deg, lat: 0, size: 0.35, color: '#9e3f22', stretch: 2.2 }, { lon: 160 * deg, lat: 18 * deg, size: 0.12, color: '#e08a5c' },
    { lon: 250 * deg, lat: -20 * deg, size: 0.25, color: '#a8492a' },
  ] },
  Jupiter: { spin: 1.4, bands: [
    [-0.75, 0.12, '#b88456'], [-0.45, 0.1, '#f1d9b5'], [-0.2, 0.14, '#a8683e'], [0.1, 0.12, '#f3dfc0'],
    [0.35, 0.14, '#b77a4a'], [0.62, 0.1, '#e9cda6'], [0.85, 0.08, '#9c6c48'],
  ], spots: [{ lon: 0, lat: -22 * deg, size: 0.16, color: '#c4533a', stretch: 1.7 }] },
  Saturn: { spin: 1.3, bands: [[-0.6, 0.15, '#cdb27a'], [-0.2, 0.12, '#f3e3b8'], [0.15, 0.16, '#c9a96c'], [0.55, 0.14, '#efdcaa']] },
  Uranus: { spin: 0.8, atmo: 'rgba(170,240,245,0.5)', bands: [[0.2, 0.25, 'rgba(255,255,255,0.12)']] },
  Neptune: { spin: 0.9, atmo: 'rgba(110,140,255,0.55)', bands: [[-0.3, 0.12, 'rgba(140,170,255,0.3)'], [0.4, 0.1, 'rgba(30,50,160,0.35)']],
    spots: [{ lon: 0, lat: -20 * deg, size: 0.14, color: '#1e2f8f', stretch: 1.6 }, { lon: 90 * deg, lat: 30 * deg, size: 0.06, color: '#e6ecff', stretch: 2 }] },
};

const customCache = new Map<number, Look>();
function lookFor(b: Body): Look {
  if (LOOKS[b.name]) return LOOKS[b.name];
  let l = customCache.get(b.id);
  if (!l) {
    let seed = b.id * 9301 + 49297;
    const rnd = () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
    l = {
      spin: 0.4 + rnd(),
      bands: Array.from({ length: 4 }, () => [rnd() * 1.8 - 0.9, 0.06 + rnd() * 0.12, rnd() > 0.5 ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.2)'] as [number, number, string]),
      spots: Array.from({ length: 3 }, () => ({ lon: rnd() * 6.28, lat: (rnd() - 0.5) * 1.6, size: 0.1 + rnd() * 0.2, color: 'rgba(0,0,0,0.22)', stretch: 1 + rnd() })),
    };
    customCache.set(b.id, l);
  }
  return l;
}

function spot(ctx: Ctx, s: Spot, sx: number, sy: number, r: number, spin: number, viewLon = 0, viewLat = 0) {
  // Longitude is camera-relative: the texture wraps around the sphere as the observer orbits it.
  const lon = s.lon + spin - viewLon;
  const lat = Math.max(-1.52, Math.min(1.52, s.lat - viewLat * 0.42));
  const c = Math.cos(lon);
  if (c < 0.035) return;
  const x = sx + r * Math.sin(lon) * Math.cos(lat);
  const y = sy - r * Math.sin(lat);
  ctx.fillStyle = s.color;
  ctx.beginPath();
  ctx.ellipse(x, y, s.size * r * c * (s.stretch ?? 1), s.size * r, 0, 0, Math.PI * 2);
  ctx.fill();
}

/** Paints surface features (bands, continents, storms, ice caps, clouds) clipped to the disc */
const textureCache = new Map<number, Spot[]>();
function proceduralTexture(b: Body) {
  let spots = textureCache.get(b.id);
  if (spots) return spots;
  let seed = b.id * 741103 + 9137;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  const base = b.color.startsWith('#') ? b.color : '#8a8f9c';
  spots = Array.from({ length: 38 }, (_, i) => ({
    lon: rnd() * Math.PI * 2, lat: (rnd() - 0.5) * 2.35,
    size: i < 9 ? 0.055 + rnd() * 0.075 : 0.018 + rnd() * 0.045,
    color: i % 5 === 0 ? 'rgba(255,255,255,0.22)' : i % 3 === 0 ? shade(base, 1.35) : shade(base, 0.58),
    stretch: 0.65 + rnd() * 2.2,
  }));
  textureCache.set(b.id, spots);
  return spots;
}

export function drawSurface(ctx: Ctx, b: Body, sx: number, sy: number, r: number, t: number, viewLon = 0, viewLat = 0) {
  const look = lookFor(b);
  const spin = t * look.spin * 0.25 + b.id;
  ctx.save();
  ctx.beginPath();
  ctx.arc(sx, sy, r, 0, Math.PI * 2);
  ctx.clip();
  for (const [y, hgt, col] of look.bands ?? []) {
    ctx.fillStyle = col;
    ctx.fillRect(sx - r, sy + y * r - (hgt * r) / 2, r * 2, hgt * r);
  }
  for (const s of proceduralTexture(b)) spot(ctx, s, sx, sy, r, spin, viewLon, viewLat);
  for (const s of look.spots ?? []) spot(ctx, s, sx, sy, r, spin, viewLon, viewLat);
  if (look.clouds) {
    ctx.fillStyle = 'rgba(255,255,255,0.55)';
    for (let i = 0; i < 6; i++) spot(ctx, { lon: i * 1.1, lat: Math.sin(i * 2.3) * 0.9, size: 0.12, color: 'rgba(255,255,255,0.5)', stretch: 2.5 }, sx, sy, r, spin * 1.15, viewLon, viewLat);
  }
  if (look.caps) {
    ctx.fillStyle = look.caps;
    ctx.beginPath(); ctx.ellipse(sx, sy - r * 0.95, r * 0.45, r * 0.18, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(sx, sy + r * 0.97, r * 0.35, r * 0.13, 0, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();
}

export const lookSpin = (b: Body, t: number) => t * lookFor(b).spin * 0.25 + b.id;

export function atmosphereFor(b: Body) { return lookFor(b).atmo; }
