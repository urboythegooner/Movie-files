import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { LogOut, Minus, Plus, Save, Swords, Minimize2, Maximize2, Volume2, VolumeX } from 'lucide-react';
import WarRoom, { BattleFeed } from './components/WarRoom';
import { AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { Toaster } from '@project/components/ui/sonner';
import HomeScreen from './components/HomeScreen';
import SaveDialog from './components/SaveDialog';
import { listSaves, loadPrefs, Prefs, readSave, writeSave } from './sim/saves';
import { Button } from '@project/components/ui/button';
import SpaceCanvas from './components/SpaceCanvas';
import Toolbar, { toolHint } from './components/Toolbar';
import TimeControls from './components/TimeControls';
import WorldPanel from './components/WorldPanel';
import Inspector from './components/Inspector';
import FactsDialog from './components/FactsDialog';
import MiniMap from './components/MiniMap';
import InventoryDialog from './components/InventoryDialog';
import { SpawnSpec } from './sim/catalog';
import { Settings, Sim, Tool } from './sim/sim';
import { YEAR } from './sim/setup';

const KEY_TOOLS: Record<string, Tool> = { '1': 'select', '2': 'asteroid', '3': 'blackhole', '4': 'planet' };

export default function App() {
  const sim = useMemo(() => new Sim(), []);
  const [, setTick] = useState(0);
  const [hidden, setHidden] = useState(false);
  const [minimized, setMinimized] = useState({ controls: false, map: false, toolbar: false, world: false, inspector: false });
  const toggleMinimized = (key: keyof typeof minimized) => setMinimized((m) => ({ ...m, [key]: !m[key] }));
  const [factsId, setFactsId] = useState<number | null>(null);
  const [invOpen, setInvOpen] = useState(false);
  const [warOpen, setWarOpen] = useState(false);
  const [home, setHome] = useState(true);
  const [prefs, setPrefs] = useState<Prefs>(loadPrefs);
  const [slot, setSlot] = useState<{ id: string; name: string } | null>(null);
  const [saveMode, setSaveMode] = useState<null | 'save' | 'quit'>(null);
  const refresh = useCallback(() => setTick((t) => t + 1), []);
  const applyPrefs = (p: Prefs) => Object.assign(sim.settings, {
    ultra: p.mode === 'ultra', simple: p.mode === 'simple', prediction: p.prediction, trails: p.trails,
    labels: p.labels, orbitAssist: p.orbitAssist, paused: false, slow: false, tool: 'select',
  });
  const startNew = () => { applyPrefs(prefs); sim.reset(); setSlot(null); setFactsId(null); setHome(false); };
  const loadGalaxy = (id: string) => {
    const d = readSave(id);
    if (!d) { toast.error('That save could not be read'); return; }
    applyPrefs(prefs); sim.load(d);
    setSlot({ id, name: listSaves().find((x) => x.id === id)?.name ?? 'Galaxy' }); setHome(false); toast.success('Galaxy loaded');
  };
  const quitHome = () => { setSaveMode(null); setInvOpen(false); setFactsId(null); sim.select(null); setHome(true); };
  const doSave = (name: string) => {
    try {
      const m = writeSave(name, sim.serialize(), slot?.name === name ? slot.id : undefined);
      setSlot({ id: m.id, name }); toast.success(`Saved "${name}"`);
      if (saveMode === 'quit') quitHome(); else setSaveMode(null);
    } catch { toast.error('Not enough storage space to save this galaxy'); }
  };
  const setUltra = useCallback((v: boolean) => {
    Object.assign(sim.settings, { ultra: v, simple: v ? false : sim.settings.simple, timeScale: Math.min(sim.settings.timeScale, v ? 20 : 6) });
    sim.reset();
    setTick((t) => t + 1);
  }, [sim]);
  const update = useCallback((p: Partial<Settings>) => { Object.assign(sim.settings, p); refresh(); }, [sim, refresh]);

  const homeRef = useRef(home);
  homeRef.current = home;
  useEffect(() => {
    document.documentElement.classList.add('dark');
    sim.onSelect = refresh;
    sim.onOpenFacts = setFactsId;
    const id = setInterval(refresh, 300);
    const onKey = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).closest('input,textarea') || homeRef.current) return;
      const k = e.key.toLowerCase();
      if (k === 'i' && !e.ctrlKey && !e.metaKey) { setInvOpen((o) => !o); return; }
      if (k === 'w' && sim.settings.travel) { setWarOpen((o) => !o); return; }
      if (k === 'b' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); setHidden((h) => !h); return; }
      if (k === 'g') update({ slow: !sim.settings.slow });
      else if (k === ' ') { e.preventDefault(); update({ paused: !sim.settings.paused }); }
      else if (k === 'l') { if (sim.settings.ultra) setUltra(false); update({ simple: !sim.settings.simple }); }
      else if (k === 'u') setUltra(!sim.settings.ultra);
      else if (k === 'p') update({ prediction: !sim.settings.prediction });
      else if (k === 'f' && sim.selectedId != null) { sim.followId = sim.followId === sim.selectedId ? null : sim.selectedId; refresh(); }
      else if (k === 'delete' || k === 'backspace') sim.destroySelected();
      else if (k === 'escape') { if (sim.settings.tool === 'place') { sim.pending = null; update({ tool: 'select' }); } else sim.select(null); }
      else if (KEY_TOOLS[k]) update({ tool: KEY_TOOLS[k] });
    };
    window.addEventListener('keydown', onKey);
    return () => { clearInterval(id); window.removeEventListener('keydown', onKey); };
  }, [sim, refresh, update, setUltra]);

  const w = sim.world;
  const asteroids = w.bodies.filter((b) => b.kind === 'asteroid').length;
  const s = sim.settings;

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-background text-foreground">
      <SpaceCanvas sim={sim} />
      <Toaster />
      <AnimatePresence>{home && <HomeScreen prefs={prefs} setPrefs={setPrefs} onNew={startNew} onLoad={loadGalaxy} />}</AnimatePresence>
      <SaveDialog open={saveMode != null} quit={saveMode === 'quit'} defaultName={slot?.name ?? `Galaxy ${new Date().toLocaleDateString()}`}
        onOpenChange={(o) => !o && setSaveMode(null)} onSave={doSave} onQuitNoSave={quitHome} />
      <InventoryDialog
        open={invOpen}
        onOpenChange={setInvOpen}
        onPick={(spec: SpawnSpec) => { sim.pending = spec; update({ tool: 'place' }); setInvOpen(false); }}
      />
      {s.tool === 'place' && sim.pending && (
        <div className="panel pointer-events-none absolute bottom-14 left-1/2 z-10 -translate-x-1/2 px-3 py-2 text-xs">
          Placing <span className="font-semibold text-primary">{sim.pending.name}</span>: click in space · Esc to stop
        </div>
      )}
      {s.travel && !home && <WarRoom sim={sim} open={warOpen} onOpenChange={setWarOpen} refresh={refresh} />}
      {s.travel && !home && !hidden && <BattleFeed sim={sim} />}
      <FactsDialog sim={sim} id={factsId} onClose={() => setFactsId(null)} refresh={refresh} />
      {home ? null : hidden ? (
        <div className="pointer-events-none absolute bottom-3 left-1/2 -translate-x-1/2 text-[10px] text-muted-foreground/60">Ctrl+B to show menus</div>
      ) : (<>

      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-3">
        <div className="pointer-events-auto">
          <h1 className="font-pixel text-sm text-primary drop-shadow-[0_0_16px_rgba(96,220,245,0.28)] sm:text-lg">SOLARIS <span className="ml-1 text-[9px] font-medium tracking-[0.18em] text-muted-foreground">SANDBOX</span></h1>
          <div className="mt-1.5 flex flex-wrap gap-x-3 text-[10px] tabular-nums text-muted-foreground">
            <span>{w.bodies.length - asteroids} bodies</span>{s.simple && <span className="text-primary">simple</span>}{s.ultra && <span className="text-primary">ultra</span>}
            <span>{asteroids} asteroids</span>
            <span>{w.debris.length} debris fragments</span>{s.travel && <span className="text-primary">🚀 {sim.fleet.ships.length} ships</span>}
            <span>yr {(w.time / YEAR).toFixed(2)}</span>
            <span>{Math.round(sim.fps)} fps</span>
          </div>
          <div className="mt-2 flex gap-1.5">
            <Button size="sm" variant="secondary" className="h-7 text-xs" onClick={() => setSaveMode('save')}><Save className="mr-1 h-3.5 w-3.5" />Save</Button>
            <Button size="sm" variant="outline" className="h-7 w-8 px-0" title={sim.soundEnabled ? 'Mute impact sounds' : 'Enable impact sounds'} aria-label={sim.soundEnabled ? 'Mute impact sounds' : 'Enable impact sounds'} onClick={() => { sim.soundEnabled = !sim.soundEnabled; refresh(); }}>{sim.soundEnabled ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5" />}</Button>
            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setSaveMode('quit')}><LogOut className="mr-1 h-3.5 w-3.5" />Save &amp; quit</Button>
            {s.travel && <Button size="sm" variant="destructive" className="h-7 text-xs" onClick={() => setWarOpen(true)}><Swords className="mr-1 h-3.5 w-3.5" />War Room</Button>}
          </div>
        </div>
        <div className="pointer-events-auto flex flex-col items-end gap-2">
          <div className="flex items-start gap-1">
            {!minimized.controls && <TimeControls s={s} update={update} onUltra={setUltra} />}
            <Button size="icon" variant="secondary" className="h-8 w-8 shrink-0" title={minimized.controls ? 'Restore controls' : 'Minimize controls'} onClick={() => toggleMinimized('controls')}>
              {minimized.controls ? <Maximize2 className="h-3.5 w-3.5" /> : <Minimize2 className="h-3.5 w-3.5" />}
            </Button>
          </div>
          <div className="hidden items-start gap-1 sm:flex">
            {!minimized.map && <MiniMap sim={sim} />}
            <Button size="icon" variant="secondary" className="h-7 w-7 shrink-0" title={minimized.map ? 'Restore minimap' : 'Minimize minimap'} onClick={() => toggleMinimized('map')}>
              {minimized.map ? <Maximize2 className="h-3 w-3" /> : <Minimize2 className="h-3 w-3" />}
            </Button>
          </div>
        </div>
      </div>

      {s.slow && (
        <div className="font-pixel pointer-events-none absolute left-1/2 top-16 -translate-x-1/2 animate-pulse text-[10px] text-primary">SLOW MOTION</div>
      )}
      {s.paused && (
        <div className="font-pixel pointer-events-none absolute left-1/2 top-24 -translate-x-1/2 text-[10px] text-muted-foreground">PAUSED</div>
      )}

      <div className="absolute left-3 top-1/2 flex -translate-y-1/2 items-start gap-1">
        {!minimized.toolbar && <Toolbar tool={s.tool} onChange={(t) => { sim.pending = null; update({ tool: t }); }} onInventory={() => setInvOpen(true)} />}
        <Button size="icon" variant="secondary" className="h-7 w-7 shrink-0" title={minimized.toolbar ? 'Restore tools' : 'Minimize tools'} onClick={() => toggleMinimized('toolbar')}>
          {minimized.toolbar ? <Maximize2 className="h-3 w-3" /> : <Minimize2 className="h-3 w-3" />}
        </Button>
      </div>

      <div className="absolute bottom-3 left-3 hidden items-start gap-1 md:flex">
        {!minimized.world && <WorldPanel sim={sim} update={update} />}
        <Button size="icon" variant="secondary" className="h-7 w-7 shrink-0" title={minimized.world ? 'Restore world panel' : 'Minimize world panel'} onClick={() => toggleMinimized('world')}>
          {minimized.world ? <Maximize2 className="h-3 w-3" /> : <Minimize2 className="h-3 w-3" />}
        </Button>
      </div>

      <div className="absolute right-3 top-20 flex items-start gap-1 sm:top-[17.5rem]">
        {!minimized.inspector && <Inspector sim={sim} refresh={refresh} onFacts={setFactsId} />}
        <Button size="icon" variant="secondary" className="h-7 w-7 shrink-0" title={minimized.inspector ? 'Restore inspector' : 'Minimize inspector'} onClick={() => toggleMinimized('inspector')}>
          {minimized.inspector ? <Maximize2 className="h-3 w-3" /> : <Minimize2 className="h-3 w-3" />}
        </Button>
      </div>

      <div className="panel absolute bottom-3 right-3 flex flex-col gap-1 p-1">
        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => sim.zoomBy(0.7)}><Plus className="h-4 w-4" /></Button>
        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => sim.zoomBy(1.4)}><Minus className="h-4 w-4" /></Button>
      </div>

      <div className="pointer-events-none absolute bottom-4 left-1/2 hidden -translate-x-1/2 text-center text-[10px] text-muted-foreground lg:block">
        {toolHint(s.tool)} · right-drag rotate · scroll zoom · G slow-mo · L simple · U ultra · Space pause · Del shatter · double-click planet for facts · I inventory · Ctrl+B hide menus
      </div>
      </>)}
    </div>
  );
}
