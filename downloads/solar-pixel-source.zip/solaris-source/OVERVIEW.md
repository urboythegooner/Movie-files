# Solar Pixel

A playful 3D solar system sandbox for anyone curious about space. Visitors can fling planets around, drop in black holes and asteroids, change masses, and watch how gravity reshapes orbits. Objects that collide shatter into clouds of glowing pixels. Paths can be predicted ahead of time, there's a slow-motion mode, and the real asteroid belt and a starfield are included.

Planets heat up or freeze depending on how close they are to stars (visible as glowing or frosted worlds). Visitors can design their own stars with a chosen temperature, add moons to any planet, and turn on Space Travel so worlds with intelligent life send ships to settle other planets.
