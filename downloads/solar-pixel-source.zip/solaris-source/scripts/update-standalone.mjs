import { readFileSync, writeFileSync } from 'node:fs';
import { join, basename } from 'node:path';

const root = new URL('../', import.meta.url).pathname;
const dist = join(root, 'dist');
const downloads = join(root, 'public', 'downloads');
let html = readFileSync(join(dist, 'index.html'), 'utf8');

const jsTag = html.match(/<script[^>]*src="(\/assets\/[^"]+\.js)"[^>]*>/);
if (jsTag) {
  const jsPath = join(dist, 'assets', basename(jsTag[1]));
  const js = readFileSync(jsPath, 'utf8').replace(/<\/script/gi, '<\\/script');
  const close = html.indexOf('</script>', jsTag.index + jsTag[0].length);
  if (close >= 0) html = html.slice(0, jsTag.index) + '<script type="module">' + js + '</script>' + html.slice(close + 9);
}
const cssTag = html.match(/<link[^>]*href="([^"]+\.css)"[^>]*>/);
if (cssTag) {
  const css = readFileSync(join(dist, 'assets', basename(cssTag[1])), 'utf8');
  html = html.replace(cssTag[0], '<style>' + css + '</style>');
}
html = html.replace(/<link rel="icon"[^>]*>/g, '');
html = html.replace('<title>SOLARIS — Gravity Sandbox</title>', '<title>SOLARIS — Gravity Sandbox</title><meta name="description" content="SOLARIS gravity sandbox — standalone edition">');
writeFileSync(join(downloads, 'solar-pixel-standalone.html'), html);
console.log('Updated standalone download from current production build (' + Math.round(Buffer.byteLength(html) / 1024) + ' KB).');
